#!/bin/bash

BENCH=edu.berkeley.cs.wise.benchmarks
RAND_RUNS=10000

# Set YICES_CMD to point to a Yices solver binary.
YICES_CMD=yices

function do_exhaustive_search {
    echo "****************************************************************"
    echo "exhaustive search $1 $2"
    echo "****************************************************************"
    echo
    time java -cp tmpclasses:classes -Dconcolic.yices=${YICES_CMD} \
        -Xmx2000m -Dconcolic.iterations=2000000000 \
        -Dconcolic.generator.join=true \
        edu.berkeley.cs.wise.concolic.ConcolicBranchPolicySearch $1 $2
    echo
}

function do_forced_exhaustive_search {
    echo "****************************************************************"
    echo "exhaustive search (force $1) $2 $3"
    echo "****************************************************************"
    echo
    time java -cp tmpclasses:classes -Dconcolic.yices=${YICES_CMD} \
        -Xmx2000m -Dconcolic.iterations=2000000000 \
        -Dconcolic.generator.override.index=$1 \
        edu.berkeley.cs.wise.concolic.ConcolicBranchPolicySearch $2 $3
    echo
}

function do_guided_search {
    echo "****************************************************************"
    echo "guided search $@"
    echo "****************************************************************"
    echo
    time java -cp tmpclasses:classes -Dconcolic.yices=${YICES_CMD} \
        -Xmx2000m -Dconcolic.iterations=2000000000 \
        edu.berkeley.cs.wise.concolic.ConcolicBranchPolicyGuided $1 $2
    echo
}

function do_random_runs {
    echo "****************************************************************"
    echo "random runs (${RAND_RUNS}) $1 $2"
    echo "****************************************************************"
    echo
    time java -cp randomclasses:classes \
        -Xmx2000m -Dconcolic.iterations=${RAND_RUNS} \
        edu.berkeley.cs.wise.concolic.ConcolicRandom $1 $2
    echo
}


rm -f concolic.summaries
for i in {1..2} ; do do_exhaustive_search $BENCH.SortedListInsert $i ; done
for i in {1..30} ; do do_guided_search $BENCH.SortedListInsert $i ; done
for i in {3..8} ; do do_exhaustive_search $BENCH.SortedListInsert $i ; done
for i in {1..30} ; do do_random_runs $BENCH.SortedListInsert $i ; done


rm -f concolic.summaries
for i in {1..4} ; do do_exhaustive_search $BENCH.BinaryTreeSearch $i ; done
for i in {1..30} ; do do_guided_search $BENCH.BinaryTreeSearch $i ; done
for i in {5..8} ; do do_exhaustive_search $BENCH.BinaryTreeSearch $i ; done
for i in {1..30} ; do do_random_runs $BENCH.BinaryTreeSearch $i ; done


rm -f concolic.summaries
for i in {1..2} ; do do_exhaustive_search $BENCH.HeapInsertJDK15 $i ; done
for i in {1..30} ; do do_guided_search $BENCH.HeapInsertJDK15 $i ; done
for i in {3..13} ; do do_exhaustive_search $BENCH.HeapInsertJDK15 $i ; done
for i in {1..30} ; do do_random_runs $BENCH.HeapInsertJDK15 $i ; done


rm -f concolic.summaries
for i in {1..8} ; do do_exhaustive_search $BENCH.RedBlackTreeSearch $i ; done
for i in {1..30} ; do do_guided_search $BENCH.RedBlackTreeSearch $i ; done
for i in {1..30} ; do do_random_runs $BENCH.RedBlackTreeSearch $i ; done


rm -f concolic.summaries
for i in {1..2} ; do do_exhaustive_search $BENCH.BellmanFord $i ; done
for i in {1..30} ; do do_guided_search $BENCH.BellmanFord $i ; done
for i in {3..4} ; do do_exhaustive_search $BENCH.BellmanFord $i ; done
for i in {1..30} ; do do_random_runs $BENCH.BellmanFord $i ; done


rm -f concolic.summaries
for i in {1..3} ; do do_exhaustive_search $BENCH.Dijkstra $i ; done
for i in {1..30} ; do do_guided_search $BENCH.Dijkstra $i ; done
for i in {4..6} ; do do_exhaustive_search $BENCH.Dijkstra $i ; done
for i in {1..30} ; do do_random_runs $BENCH.Dijkstra $i ; done


rm -f concolic.summaries
for i in {1..3} ; do do_exhaustive_search $BENCH.Tsp $i ; done
do_forced_exhaustive_search 2 $BENCH.Tsp 4
for i in {1..9} ; do do_guided_search $BENCH.Tsp $i ; done
for i in {1..10} ; do do_random_runs $BENCH.Tsp $i ; done
ORR=${RAND_RUNS} ; RAND_RUNS=1000
for i in {11..15} ; do do_random_runs $BENCH.Tsp $i ; done
RAND_RUNS=${ORR}


rm -f concolic.summaries
for i in {1..2} ; do do_exhaustive_search $BENCH.InsertionSort $i ; done
for i in {1..30} ; do do_guided_search $BENCH.InsertionSort $i ; done
for i in {3..9} ; do do_exhaustive_search $BENCH.InsertionSort $i ; done
for i in {1..30} ; do do_random_runs $BENCH.InsertionSort $i ; done


rm -f concolic.summaries
for i in {1..8} ; do do_exhaustive_search $BENCH.QuickSortJDK15 $i ; done
for i in {1..30} ; do do_guided_search $BENCH.QuickSortJDK15 $i ; done
for i in {9..9} ; do do_exhaustive_search $BENCH.QuickSortJDK15 $i ; done
for i in {1..30} ; do do_random_runs $BENCH.QuickSortJDK15 $i ; done


# Doesn't scale well.
rm -f concolic.summaries
for i in {1..7} ; do do_exhaustive_search $BENCH.MergeSortJDK15 $i ; done
for i in {1..14} ; do do_guided_search $BENCH.MergeSortJDK15 $i ; done
for i in {8..9} ; do do_exhaustive_search $BENCH.MergeSortJDK15 $i ; done
for i in {1..30} ; do do_random_runs $BENCH.MergeSortJDK15 $i ; done
