/**
 * Copyright (c) 2011, Regents of the University of California
 * All rights reserved.
 * <p/>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * <p/>
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * <p/>
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 * <p/>
 * 3. Neither the name of the University of California, Berkeley nor
 * the names of its contributors may be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 * <p/>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package edu.berkeley.cs.wise.concolic;

import edu.berkeley.cs.wise.concolic.generators.Generator;

import java.io.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.TreeSet;

/**
 * @author Koushik Sen <ksen@cs.berkeley.edu>
 * @author Jacob Burnim <jburnim@cs.berkeley.edu>
 */
public class ConcolicEventHandler {
    private SymbolicState state;
    private long[] concreteComptationStack;
    private ArrayList<Expression> symbolicComputationStack;
    private LinkedList<Expression> symbolicArgumentList;
    private Expression symbolicReturn;
    private PathConstraint pathConstraint;
    private Strategy strategy;
    private TreeSet<Integer> branchesCovered;

    private boolean concolicOn;
    private int inputCounter;

    private History history;
    private Generator generator;
    private boolean coverageOn;

    private final boolean DEBUG = false;

    public void SetMode(int mode) {
        Globals.mode = mode;
    }

    public void Initialize() {
        Globals.initialize();
    }

    public ConcolicEventHandler(History h) {
        concolicOn = false;
        coverageOn = !System.getProperty("concolic.coverage", "false").equals("false");
        inputCounter = 0;
        state = new SymbolicState();
        concreteComptationStack = new long[100];
        symbolicComputationStack = new ArrayList<Expression>();
        symbolicArgumentList = new LinkedList<Expression>();
        pathConstraint = new PathConstraint();

        if (h == null) {
            if (Globals.mode == Globals.PERSIST_MODE) history = History.readHistory();
            else history = new History();
        } else {
            history = h;
        }

        strategy = new Strategy(history, pathConstraint);
        branchesCovered = new TreeSet<Integer>();
    }

    private void resetAll() {
        concolicOn = false;
        inputCounter = 0;
        state.reset();
        symbolicComputationStack.clear();
        symbolicArgumentList.clear();
        history.reset();
        pathConstraint.reset();

    }

    public void restartFromScratch() {
        resetAll();
        history.restart();
    }

    public History SolveToCreateTask() {
        History ret = strategy.solveFromBeginning();
        if (ret != null) ret.reset();
        return ret;
    }

    public boolean SolveAndReset() {
        if (DEBUG) {
            history.print();
            pathConstraint.print();
            System.out.println();
        }

        if (Globals.mode == Globals.PERF_BRANCH_POLICY_FIND_MODE) {
            strategy.solveAllBranches();  // determine which branches are feasible
            Globals.max.updateMaxHistory(history);
        } else if ((Globals.mode == Globals.PERF_BRANCH_SET_FIND_MODE)
                   || (Globals.mode == Globals.PERF_RANDOM_MODE)) {
            Globals.max.updateMaxHistory(history);
        }

        if (Globals.mode == Globals.PERF_RANDOM_MODE) {
            restartFromScratch();
            return true;  // keep running until we exhaust the iteration budget
        }

        int ret = 0;
        if ((Globals.mode == Globals.PERF_BRANCH_SET_SOLVE_MODE)
            || (Globals.mode == Globals.PERF_BRANCH_POLICY_SOLVE_MODE)) {
            ret = strategy.solve(readGenerator(), Globals.max, inputCounter);
        } else {
            // Continue depth-first exhaustive search.
            ret = strategy.solve();
        }
        boolean done = (ret != 0);

        if (DEBUG) {
            System.out.println(history.getInputs());
            history.print();
            System.out.println();
        }

        if (done) {
            if ((Globals.mode == Globals.PERF_BRANCH_SET_FIND_MODE)
                || (Globals.mode == Globals.PERF_BRANCH_POLICY_FIND_MODE)) {

                Globals.max.printTraces(Globals.maxHistoryFileNamePrefix + inputCounter + ".html");
                Generator maxGenerator = null;
                if (Globals.generatorIndexToSelect >= 0) {
                    maxGenerator = Globals.max.getMaximalGenerator(Globals.generatorIndexToSelect);
                } else {
                    maxGenerator = Globals.max.getBestMaximalGenerator();
                }
                writeGenerator(maxGenerator);
                System.out.println("############################################ Generator:");
                System.out.println(maxGenerator.toString());
                System.out.println();
                System.out.println("Solver calls: " + strategy.getSolverCount());

            } else if ((Globals.mode == Globals.PERF_BRANCH_SET_SOLVE_MODE)
                    || (Globals.mode == Globals.PERF_BRANCH_POLICY_SOLVE_MODE)) {

                Globals.max.printStats();
                Globals.max.printTraces(Globals.maxHistoryFileNamePrefix + inputCounter + ".html");
                System.out.println("Solver calls: " + strategy.getSolverCount());
            }
        }

        resetAll();
        if (coverageOn) {
            System.out.println("Branches covered " + branchesCovered.size());
        }
        return !done;
    }

    public void Shutdown() {
        if (Globals.mode == Globals.PERF_RANDOM_MODE) {
            Globals.max.printStats();
        }
    }

    private Generator readGenerator() {
        if (generator != null)
            return generator;

        ObjectInputStream in;
        try {
            in = new ObjectInputStream(new BufferedInputStream(new FileInputStream(Globals.generatorFile)));
            generator = (Generator) in.readObject();
            in.close();
            return generator;
        } catch (IOException e) {
            e.printStackTrace();
            Runtime.getRuntime().halt(1);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            Runtime.getRuntime().halt(1);
        }
        return null;
    }

    private void writeGenerator(Generator gen) {
        ObjectOutputStream out;
        try {
            out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(Globals.generatorFile)));
            out.writeObject(gen);
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
            Runtime.getRuntime().halt(1);
        }
    }

    private void deleteGenerator() {
        File generatorFile = new File(Globals.generatorFile);
        generatorFile.delete();
    }

    public int SolveAndPersist() {
        if (Globals.mode == Globals.PERSIST_MODE) {
            int ret = strategy.solve();
            history.writeHistory();
            return ret;
        } else if (Globals.mode == Globals.FAST_DEFAULT_MODE) {
            history.writeInputs();
        }
        return 1;
    }


    public long GetInput(long MIN, long MAX, long defaultVal) {
        if (DEBUG)
            System.out.println("GetInput(" + MIN + "," + MAX + "," + defaultVal + ")");
        return history.addAndReturnInput(MIN, MAX, defaultVal);
    }

    public void MakeSymbolic(long MIN, long MAX) {
        if (DEBUG)
            System.out.println("MakeSymbolic(" + MIN + "," + MAX + ")");
        if (Globals.mode == Globals.PERF_RANDOM_MODE) {
            // Keep all inputs concrete.
            return;
        }

        if (!concolicOn) {
            //System.out.println("Input");
            //history.print();
            concolicOn = true;
            if (Globals.mode == Globals.PERSIST_MODE) {
                Runtime.getRuntime().addShutdownHook(new ShutdownThread(this));
            }
        }
        Expression e = new LinearExpression(inputCounter++);

        Expression e1 = e.subtractFrom(MIN);
        e1.setop("<=");
        pathConstraint.addConstraint(e1);

        Expression e2 = e.subtract(MAX);
        e2.setop("<=");
        pathConstraint.addConstraint(e2);

        symbolicReturn = e;
    }

    public void LoadValue(int iid, int type, long l) {
        if (DEBUG)
            System.out.println("LoadValue(" + iid + "," + type + "," + l + ")");
        if (!concolicOn) return;
        concreteComptationStack[symbolicComputationStack.size()] = l;
    }

    public void LoadValue(int iid, int type, boolean b) {
        if (DEBUG)
            System.out.println("LoadValue(" + iid + "," + type + "," + b + ")");
        if (!concolicOn) return;
        concreteComptationStack[symbolicComputationStack.size()] = b ? 1 : 0;
    }

    public void LoadAddress(int iid, long l) {
        if (DEBUG)
            System.out.println("LoadAddress(" + iid + "," + l + ")");
        if (!concolicOn) return;
        Expression e = state.getExpression(l);
        symbolicComputationStack.add(e);
    }

    public void LoadReturnAddress(int iid, long l) {
        if (DEBUG)
            System.out.println("LoadReturnAddress(" + iid + "," + l + ")");
        if (!concolicOn) return;
        symbolicReturn = state.getExpression(l);
    }

    public void LoadArgumentAddress(int iid, long l) {
        if (DEBUG)
            System.out.println("LoadArgumentAddress(" + iid + "," + l + ")");
        if (!concolicOn) return;
        symbolicArgumentList.addLast(state.getExpression(l));
    }

    public void StoreAddress(int iid, long l) {
        if (DEBUG)
            System.out.println("StoreAddress(" + iid + "," + l + ")");
        if (!concolicOn) return;
        Expression e;
        if (!symbolicComputationStack.isEmpty()) {
            e = symbolicComputationStack.remove(symbolicComputationStack.size() - 1);
        } else {
            e = null;
        }
        state.setExpression(l, e);
    }

    public void StoreReturnAddress(int iid, long l) {
        if (DEBUG)
            System.out.println("StoreReturnAddress(" + iid + "," + l + ")");
        if (!concolicOn) return;
        state.setExpression(l, symbolicReturn);
    }

    public void StoreArgumentAddress(int iid, long l) {
        if (DEBUG)
            System.out.println("StoreArgumentAddress(" + iid + "," + l + ")");
        if (!concolicOn) return;
        if (symbolicArgumentList.isEmpty()) {
            state.setExpression(l, null);
        } else {
            Expression e = symbolicArgumentList.removeFirst();
            state.setExpression(l, e);
        }
    }

    public void ApplyOp(int iid, String op) {
        if (DEBUG)
            System.out.println("ApplyOp(" + iid + "," + op + ")");
        if (!concolicOn) return;
        Expression e = null;
        if (symbolicComputationStack.size() == 1 && op.equals("-")) {
            e = symbolicComputationStack.get(0);
            if (e != null) {
                e = e.negate();
            }
        } else if (symbolicComputationStack.size() == 2) {
            if (op.equals("+")) {
                if (symbolicComputationStack.get(0) == null && symbolicComputationStack.get(1) == null) {
                    e = null;
                } else if (symbolicComputationStack.get(0) == null) {
                    e = symbolicComputationStack.get(1).add(concreteComptationStack[0]);
                } else if (symbolicComputationStack.get(1) == null) {
                    e = symbolicComputationStack.get(0).add(concreteComptationStack[1]);
                } else {
                    e = symbolicComputationStack.get(0).add(symbolicComputationStack.get(1));
                }
            } else if (op.equals("-") || op.equals("cmp")) {
                if (symbolicComputationStack.get(0) == null && symbolicComputationStack.get(1) == null) {
                    e = null;
                } else if (symbolicComputationStack.get(0) == null) {
                    e = symbolicComputationStack.get(1).subtractFrom(concreteComptationStack[0]);
                } else if (symbolicComputationStack.get(1) == null) {
                    e = symbolicComputationStack.get(0).subtract(concreteComptationStack[1]);
                } else {
                    e = symbolicComputationStack.get(0).subtract(symbolicComputationStack.get(1));
                }
            } else if (op.equals("*")) {
                if (symbolicComputationStack.get(0) == null && symbolicComputationStack.get(1) == null) {
                    e = null;
                } else if (symbolicComputationStack.get(0) == null) {
                    e = symbolicComputationStack.get(1).multiply(concreteComptationStack[0]);
                } else if (symbolicComputationStack.get(1) == null) {
                    e = symbolicComputationStack.get(0).multiply(concreteComptationStack[1]);
                } else {
                    e = symbolicComputationStack.get(0).multiply(concreteComptationStack[1]);
                }
            } else if (op.equals("<") || op.equals(">") || op.equals("==")
                    || op.equals("!=") || op.equals(">=") || op.equals("<=")) {
                if (symbolicComputationStack.get(0) == null && symbolicComputationStack.get(1) == null) {
                    e = null;
                } else if (symbolicComputationStack.get(0) == null) {
                    e = symbolicComputationStack.get(1).subtractFrom(concreteComptationStack[0]);
                } else if (symbolicComputationStack.get(1) == null) {
                    e = symbolicComputationStack.get(0).subtract(concreteComptationStack[1]);
                } else {
                    e = symbolicComputationStack.get(0).subtract(symbolicComputationStack.get(1));
                }
                if (e != null) {
                    e.setop(op);
                }
            } else {
                e = null;
            }
        } else {
            e = null;
        }
        symbolicComputationStack.clear();
        if (e != null)
            symbolicComputationStack.add(e);
    }

    public void ApplyOp(int iid, String op, String type) {
        if (DEBUG)
            System.out.println("ApplyOp(" + iid + "," + op + "," + type + ")");
        if (!concolicOn) return;
        if (!op.equals("cast"))
            symbolicComputationStack.clear();
    }

    public void MethodCall(int iid, String sig) {
        if (DEBUG)
            System.out.println("MethodCall(" + iid + "," + sig + ")");
        history.addCallToHistory(iid, true);
        state.push();
    }

    public void MethodReturn(int iid, String sig) {
        if (DEBUG)
            System.out.println("MethodReturn(" + iid + "," + sig + ")");
        history.addCallToHistory(iid, false);
        state.pop();
    }

    public void PrepareMethodCall(int iid) {
        if (DEBUG)
            System.out.println("PrepareMethodCall(" + iid + ")");
        if (!concolicOn) return;
        symbolicReturn = null;
        symbolicArgumentList.clear();
    }

    public void BranchThen(int iid, int bid) {
        if (DEBUG)
            System.out.println("BranchThen(" + iid + "," + bid + ")");
        Expression e = null;
        if (concolicOn) {
            if (!symbolicComputationStack.isEmpty())
                e = symbolicComputationStack.remove(symbolicComputationStack.size() - 1);
        }
        int loc = pathConstraint.addConstraint(e);
        history.addConstraintAndCheckBranch(iid, e, loc, true);
        if (coverageOn) {
            branchesCovered.add(bid);
        }
    }

    public void BranchElse(int iid, int bid) {
        if (DEBUG)
            System.out.println("BranchElse(" + iid + "," + bid + ")");
        Expression e = null;
        if (concolicOn) {
            if (!symbolicComputationStack.isEmpty())
                e = symbolicComputationStack.remove(symbolicComputationStack.size() - 1);
            if (e != null) {
                e.not();
            }
        }
        int loc = pathConstraint.addConstraint(e);
        history.addConstraintAndCheckBranch(iid - 1, e, loc, false);
        if (coverageOn) {
            branchesCovered.add(bid);
        }
    }

    public void ResetBranchCounting() {
        if (DEBUG)
            System.out.println("ResetBranchCounting()");
        history.ResetBranchCounting();
    }

}
