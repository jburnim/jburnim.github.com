/**
 * Copyright (c) 2011, Regents of the University of California
 * All rights reserved.
 * <p/>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * <p/>
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * <p/>
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 * <p/>
 * 3. Neither the name of the University of California, Berkeley nor
 * the names of its contributors may be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 * <p/>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package edu.berkeley.cs.wise.concolic;

import edu.berkeley.cs.wise.instrumentor.Visitor;
import edu.berkeley.cs.wise.instrumentor.contexts.*;
import soot.*;
import soot.jimple.*;
import soot.jimple.internal.JCaughtExceptionRef;
import soot.util.Chain;

import java.util.LinkedList;

/**
 * @author Koushik Sen <ksen@cs.berkeley.edu>
 */
public class VisitorForConcolic extends Visitor {
    private int branchCount = 0;
    private boolean isEmptyBody = false;

    public VisitorForConcolic(Visitor nextVisitor) {
        super(nextVisitor);
    }

    /* make sure that MethodEnd is called even if the method throws an exception

    foo() {
      body;
    }

    to

    foo() {
       try {
          body;
       } catch (java.lang.Throwable __Cal_n) {
          MethodReturn(iid,"foo()");
          throw __Cal_n;
       }
     }

     */

    public void visitMethodBegin(SootMethod sm, Chain units) {
        isEmptyBody = true;
        nextVisitor.visitMethodBegin(sm, units);
    }

    public void visitStmt(SootMethod sm, Chain units, Stmt s) {
        if (s instanceof AssignStmt || s instanceof InvokeStmt) {
            isEmptyBody = false;
        }
        nextVisitor.visitStmt(sm, units, s);
    }

    public void visitMethodEnd(SootMethod sm, Chain units) {
        nextVisitor.visitMethodEnd(sm, units);
        if (!isEmptyBody) {
            Body body = sm.retrieveActiveBody();
            Local tmpLocal = Jimple.v().newLocal("__Cal_" + body.getLocalCount(), RefType.v("java.lang.Throwable"));
            body.getLocals().add(tmpLocal);
            Stmt eStmt = Jimple.v().newIdentityStmt(tmpLocal, new JCaughtExceptionRef());
            Trap t = Jimple.v().newTrap(Scene.v().getSootClass("java.lang.Throwable"),
                    (Stmt) body.getUnits().getFirst(), (Stmt) body.getUnits().getLast(), eStmt);
            body.getTraps().addLast(t);
            units.addLast(eStmt);
            addCallWithObject(units, (Stmt) units.getLast(), "MethodReturn", StringConstant.v(sm.getSubSignature()), false);
            units.addLast(Jimple.v().newThrowStmt(tmpLocal));
        }
    }

    /*
       if (p) goto L;

       to

       if (p) goto L2;
       BranchElse(iid,bid+1);
       goto L1;
       L2: BranchThen(iid,bid);
       L1: nop;
       if (p) goto L;
    */

    public void visitStmtIf(SootMethod sm, Chain units, IfStmt ifStmt) {
        nextVisitor.visitStmtIf(sm, units, ifStmt);
        SootMethodRef mr;
        mr = Scene.v().getMethod("<" + observerClass + ": void " + "BranchThen" + "(int,int)>").makeRef();
        Stmt pos = Jimple.v().newInvokeStmt(Jimple.v().newStaticInvokeExpr(mr, IntConstant.v(getAndIncCounter()),
                IntConstant.v(branchCount++)));
        IfStmt is = Jimple.v().newIfStmt(ifStmt.getCondition(), pos);
        units.insertBefore(is, ifStmt);

        mr = Scene.v().getMethod("<" + observerClass + ": void " + "BranchElse" + "(int,int)>").makeRef();
        Stmt neg = Jimple.v().newInvokeStmt(Jimple.v().newStaticInvokeExpr(mr, IntConstant.v(getAndIncCounter()),
                IntConstant.v(branchCount++)));
        units.insertBefore(neg, ifStmt);

        NopStmt ns = Jimple.v().newNopStmt();
        units.insertBefore(Jimple.v().newGotoStmt(ns), ifStmt);
        units.insertBefore(pos, ifStmt);
        units.insertBefore(ns, ifStmt);
    }


    public void visitStmtLookupSwitch(SootMethod sm, Chain units, LookupSwitchStmt lookupSwitchStmt) {
        nextVisitor.visitStmtLookupSwitch(sm, units, lookupSwitchStmt);
        int sz = lookupSwitchStmt.getTargetCount();
        NopStmt ns = Jimple.v().newNopStmt();
        LinkedList linkedList = new LinkedList();
        for (int i = 0; i < sz; i++) {
            EqExpr eq = Jimple.v().newEqExpr(lookupSwitchStmt.getKey(), IntConstant.v(lookupSwitchStmt.getLookupValue(i)));
            SootMethodRef mr;
            mr = Scene.v().getMethod("<" + observerClass + ": void " + "BranchThen" + "(int,int)>").makeRef();
            Stmt pos = Jimple.v().newInvokeStmt(Jimple.v().newStaticInvokeExpr(mr, IntConstant.v(getAndIncCounter()),
                    IntConstant.v(branchCount++)));

            mr = Scene.v().getMethod("<" + observerClass + ": void " + "BranchElse" + "(int,int)>").makeRef();
            Stmt neg = Jimple.v().newInvokeStmt(Jimple.v().newStaticInvokeExpr(mr, IntConstant.v(getAndIncCounter()),
                    IntConstant.v(branchCount++)));

            visitBinopExpr(sm, units, lookupSwitchStmt, eq, IfContextImpl.getInstance());
            IfStmt ifStmt = Jimple.v().newIfStmt(eq, pos);
            units.insertBefore(ifStmt, lookupSwitchStmt);
            units.insertBefore(neg, lookupSwitchStmt);
            linkedList.addLast(pos);
        }
        units.insertBefore(Jimple.v().newGotoStmt(ns), lookupSwitchStmt);
        for (Object pos1 : linkedList) {
            Stmt stmt = (Stmt) pos1;
            units.insertBefore(stmt, lookupSwitchStmt);
            units.insertBefore(Jimple.v().newGotoStmt(ns), lookupSwitchStmt);
        }
        units.insertBefore(ns, lookupSwitchStmt);
    }


    public void visitStmtTableSwitch(SootMethod sm, Chain units, TableSwitchStmt tableSwitchStmt) {
        nextVisitor.visitStmtTableSwitch(sm, units, tableSwitchStmt);
        int sz = tableSwitchStmt.getHighIndex();
        NopStmt ns = Jimple.v().newNopStmt();
        LinkedList linkedList = new LinkedList();
        for (int i = tableSwitchStmt.getLowIndex(); i < sz; i++) {
            EqExpr eq = Jimple.v().newEqExpr(tableSwitchStmt.getKey(), IntConstant.v(i));
            SootMethodRef mr;
            mr = Scene.v().getMethod("<" + observerClass + ": void " + "BranchThen" + "(int,int)>").makeRef();
            Stmt pos = Jimple.v().newInvokeStmt(Jimple.v().newStaticInvokeExpr(mr, IntConstant.v(getAndIncCounter()),
                    IntConstant.v(branchCount++)));

            mr = Scene.v().getMethod("<" + observerClass + ": void " + "BranchElse" + "(int,int)>").makeRef();
            Stmt neg = Jimple.v().newInvokeStmt(Jimple.v().newStaticInvokeExpr(mr, IntConstant.v(getAndIncCounter()),
                    IntConstant.v(branchCount++)));

            visitBinopExpr(sm, units, tableSwitchStmt, eq, IfContextImpl.getInstance());
            IfStmt ifStmt = Jimple.v().newIfStmt(eq, pos);
            units.insertBefore(ifStmt, tableSwitchStmt);
            units.insertBefore(neg, tableSwitchStmt);
            linkedList.addLast(pos);
        }
        units.insertBefore(Jimple.v().newGotoStmt(ns), tableSwitchStmt);
        for (Object pos1 : linkedList) {
            Stmt stmt = (Stmt) pos1;
            units.insertBefore(stmt, tableSwitchStmt);
            units.insertBefore(Jimple.v().newGotoStmt(ns), tableSwitchStmt);
        }
        units.insertBefore(ns, tableSwitchStmt);
    }

    /*
        t1 = c op t3;

        to

        LoadValue(iid,0,c);
        LoadAddress(iid,0,0);
        LoadValue(iid,0,t3);
        LoadAddress(iid,0,st.get("t3");
        ApplyOp(iid,"op");
        t1 = c op t3;
        StoreValue(iid,1,t1);
        StoreAddress(iid,0,st.get("t1");
     */

    /*
        t1 = t2 op t3;

        to

        LoadValue(iid,0,t2);
        LoadAddress(iid,0,st.get("t2");
        LoadValue(iid,0,t3);
        LoadAddress(iid,0,st.get("t3");
        ApplyOp(iid,"op");
        t1 = t2 op t3;
        StoreValue(iid,1,t1);
        StoreAddress(iid,0,st.get("t1");
     */

    public void visitBinopExpr(SootMethod sm, Chain units, Stmt s, BinopExpr expr, BinopExprContext context) {
        nextVisitor.visitBinopExpr(sm, units, s, expr, context);
        addCallWithObject(units, s, "ApplyOp", StringConstant.v(expr.getSymbol().trim()), true);
    }

    /*
        t1 = - t2;

        to

        LoadValue(iid,0,t2);
        LoadAddress(iid,0,st.get("t2");
        ApplyOp(iid,"-");
        t1 = - t2;
        StoreValue(iid,1,t1);
        StoreAddress(iid,0,st.get("t1");
     */
    public void visitNegExpr(SootMethod sm, Chain units, Stmt s, NegExpr negExpr) {
        nextVisitor.visitNegExpr(sm, units, s, negExpr);
        addCallWithObject(units, s, "ApplyOp", StringConstant.v("-"), true);
    }

    /*
        t1 = t2.length;

        to

        LoadValue(iid,0,t2);
        LoadAddress(iid,0,st.get("t2");
        ApplyOp(iid,"length");
        t1 = t2.length;
        StoreValue(iid,1,t1);
        StoreAddress(iid,0,st.get("t1");
     */
    public void visitLengthExpr(SootMethod sm, Chain units, Stmt s, LengthExpr lengthExpr) {
        nextVisitor.visitLengthExpr(sm, units, s, lengthExpr);
        addCallWithObject(units, s, "ApplyOp", StringConstant.v("length"), true);
    }

    /*
        t = newmultiarray T t1 ... tn;

        to

        LoadValue(iid,0,t1);
        LoadAddress(iid,0,st.get("t1");
        ...
        LoadValue(iid,0,tn);
        LoadAddress(iid,0,st.get("tn");
        ApplyOp(iid,"newmultiarray",,"T");
        t = newmultiarray T t1 ... tn;
        StoreValue(iid,1,t);
        StoreAddress(iid,0,st.get("t");
     */
    public void visitNewMultiArrayExpr(SootMethod sm, Chain units, Stmt s, NewMultiArrayExpr newMultiArrayExpr) {
        nextVisitor.visitNewMultiArrayExpr(sm, units, s, newMultiArrayExpr);
        addCallWithObjectString(units, s, "ApplyOp", StringConstant.v("newmultiarray"),
                StringConstant.v(newMultiArrayExpr.getBaseType().toString()), true);
    }

    /*
        t = newarray T t1;

        to

        LoadValue(iid,0,t1);
        LoadAddress(iid,0,st.get("t1");
        ApplyOp(iid,"newarray",,"T");
        t = newarray T t1;
        StoreValue(iid,1,t);
        StoreAddress(iid,0,st.get("t");
     */
    public void visitNewArrayExpr(SootMethod sm, Chain units, Stmt s, NewArrayExpr newArrayExpr) {
        nextVisitor.visitNewArrayExpr(sm, units, s, newArrayExpr);
        addCallWithObjectString(units, s, "ApplyOp", StringConstant.v("newarray"),
                StringConstant.v(newArrayExpr.getBaseType().toString()), true);
    }

    /*
        t = new T;

        to

        ApplyOp(iid,"new",,"T");
        t = new T;
        StoreValue(iid,1,t);
        StoreAddress(iid,0,st.get("t");
     */
    public void visitNewExpr(SootMethod sm, Chain units, Stmt s, NewExpr newExpr) {
        nextVisitor.visitNewExpr(sm, units, s, newExpr);
        addCallWithObjectString(units, s, "ApplyOp", StringConstant.v("new"),
                StringConstant.v(newExpr.getBaseType().toString()), true);
    }

    /*
        t.foo(t1,...,tn);

        to

        PrepareMethodCall();
        LoadValue(iid,2,t);
        LoadArgumentAddress(iid,0,st.get("t");
        LoadValue(iid,2,t1);
        LoadArgumentAddress(iid,0,st.get("t1");
        ...
        LoadValue(iid,2,tn);
        LoadArgumentAddress(iid,0,st.get("tn");
        MethodCall(sigOf(foo));
        t.foo(t1,...,tn);
        MethodReturn(sigOf(foo));

     */
    /*
        t.foo(c,...,tn);

        to

        PrepareMethodCall();
        LoadValue(iid,2,t);
        LoadArgumentAddress(iid,0,st.get("t");
        LoadValue(iid,2,c);
        LoadArgumentAddress(iid,0,0);
        ...
        LoadValue(iid,2,tn);
        LoadArgumentAddress(iid,0,st.get("tn");
        MethodCall(sigOf(foo));
        t.foo(c,...,tn);
        MethodReturn(sigOf(foo));

     */
    /*
        C.foo(t1,...,tn);

        to

        PrepareMethodCall();
        LoadValue(iid,2,t1);
        LoadArgumentAddress(iid,0,st.get("t1");
        ...
        LoadValue(iid,2,tn);
        LoadArgumentAddress(iid,0,st.get("tn");
        MethodCall(sigOf(foo));
        t.foo(t1,...,tn);
        MethodReturn(sigOf(foo));

     */
    /*
        tx = t.foo(t1,...,tn);

        to

        PrepareMethodCall();
        LoadValue(iid,2,t);
        LoadArgumentAddress(iid,0,st.get("t");
        LoadValue(iid,2,t1);
        LoadArgumentAddress(iid,0,st.get("t1");
        ...
        LoadValue(iid,2,tn);
        LoadArgumentAddress(iid,0,st.get("tn");
        MethodCall(sigOf(foo));
        tx = t.foo(t1,...,tn);
        StoreValue(iid,5,tx);
        StoreAddress(iid,0,st.get("tx");
        MethodReturn(sigOf(foo));

     */

    public void visitInvokeExpr(SootMethod sm, Chain units, Stmt s, InvokeExpr invokeExpr, InvokeContext context) {
        addCall(units, s, "PrepareMethodCall", true);
        nextVisitor.visitInvokeExpr(sm, units, s, invokeExpr, context);
        addCallWithObject(units, s, "MethodCall", StringConstant.v(invokeExpr.getMethod().getSignature()), true);
        addCallWithObject(units, s, "MethodReturn", StringConstant.v(invokeExpr.getMethod().getSignature()), false);
    }

    /*
        t = t1 instanceof T;

        to

        LoadValue(iid,0,t1);
        LoadAddress(iid,0,st.get("t1");
        ApplyOp(iid,"instanceof",,"T");
        t = t1 instanceof T;
        StoreValue(iid,1,t);
        StoreAddress(iid,0,st.get("t");
     */
    public void visitInstanceOfExpr(SootMethod sm, Chain units, Stmt s, InstanceOfExpr instanceOfExpr) {
        nextVisitor.visitInstanceOfExpr(sm, units, s, instanceOfExpr);
        addCallWithObjectString(units, s, "ApplyOp", StringConstant.v("instanceof"),
                StringConstant.v(instanceOfExpr.getCheckType().toString()), true);
    }

    /*
        t = (T) t1;

        to

        LoadValue(iid,0,t1);
        LoadAddress(iid,0,st.get("t1");
        ApplyOp(iid,"cast",,"T");
        t = (T) t1;
        StoreValue(iid,1,t);
        StoreAddress(iid,0,st.get("t");
     */
    public void visitCastExpr(SootMethod sm, Chain units, Stmt s, CastExpr castExpr) {
        nextVisitor.visitCastExpr(sm, units, s, castExpr);
        addCallWithObjectString(units, s, "ApplyOp", StringConstant.v("cast"),
                StringConstant.v(castExpr.getCastType().toString()), true);
    }

    /*
        T foo(T1 t1, ..., Tn tn) {


            return t;
        }

        to

        T foo(T1 t1, ..., Tn tn) {
            StoreValue(iid,3,t);
            StoreAddress(iid,0,st.get("this");
            StoreValue(iid,3,t);
            StoreAddress(iid,0,st.get("t1");
            ...
            StoreValue(iid,3,t);
            StoreAddress(iid,0,st.get("tn");


            LoadValue(iid,4,t);
            LoadReturnAddress(iid,0,st.get("t"));
            return t;
        }

     */

    /*
        T foo(T1 t1, ..., Tn tn) {


            return t;
        }

        to

        T foo(T1 t1, ..., Tn tn) {
            StoreValue(iid,3,t);
            StoreAddress(iid,0,st.get("this");
            StoreValue(iid,3,t);
            StoreAddress(iid,0,st.get("t1");
            ...
            StoreValue(iid,3,t);
            StoreAddress(iid,0,st.get("tn");


            LoadValue(iid,4,c);
            LoadReturnAddress(iid,0,c);
            return c;
        }

     */

    /*
        static T foo(T1 t1, ..., Tn tn) {


            return t;
        }

        to

        static T foo(T1 t1, ..., Tn tn) {
            StoreValue(iid,3,t);
            StoreAddress(iid,0,st.get("t1");
            ...
            StoreValue(iid,3,t);
            StoreAddress(iid,0,st.get("tn");


            LoadValue(iid,4,t);
            LoadReturnAddress(iid,0,st.get("t");
            return t;
        }

     */

    public void visitLocal(SootMethod sm, Chain units, Stmt s, Local local, LocalContext context) {
        Type t = local.getType();
        if (!(t instanceof RefType || t instanceof ArrayType || t instanceof FloatType || t instanceof DoubleType)) {
            if (context == LookupSwitchContextImpl.getInstance() || context == TableSwitchContextImpl.getInstance()) {

            } else if (context == InvokeAndAssignTargetContextImpl.getInstance()
                    || context == InvokeAndAssignArgumentContextImpl.getInstance()
                    || context == InvokeOnlyTargetContextImpl.getInstance()
                    || context == InvokeOnlyArgumentContextImpl.getInstance()) {

//            addCallWithLocalValue(units, s, "LoadValue", 2, local, true);
                addCallWithIntInt(units, s, "LoadArgumentAddress", IntConstant.v(0), IntConstant.v(st.get(local.getName())), true);
            } else if (context == ParameterRefContextImpl.getInstance()) {
                addCallWithIntInt(units, s, "StoreArgumentAddress", IntConstant.v(0), IntConstant.v(st.get(local.getName())), false);
//            addCallWithLocalValue(units, s, "StoreValue", 3, local, false);
            } else if (context == ThisRefContextImpl.getInstance()) {
                addCallWithIntInt(units, s, "StoreArgumentAddress", IntConstant.v(0), IntConstant.v(st.get(local.getName())), false);
//            addCallWithLocalValue(units, s, "StoreValue", 3, local, false);
            } else if (context == ReturnContextImpl.getInstance()) {
                addCallWithLocalValue(units, s, "LoadValue", 4, local, true);
                addCallWithIntInt(units, s, "LoadReturnAddress", IntConstant.v(0), IntConstant.v(st.get(local.getName())), true);
            } else if (context instanceof LocalOrConstantContext) {
                addCallWithLocalValue(units, s, "LoadValue", 0, local, true);
                addCallWithIntInt(units, s, "LoadAddress", IntConstant.v(0), IntConstant.v(st.get(local.getName())), true);
            } else if (context instanceof LHSContext && s instanceof AssignStmt &&
                    ((AssignStmt) s).getRightOp() instanceof InvokeExpr) {
                addCallWithIntInt(units, s, "StoreReturnAddress", IntConstant.v(0), IntConstant.v(st.get(local.getName())), false);
                //addCallWithLocalValue(units, s, "StoreValue", 5, local, false);
            } else if (context instanceof LHSContext) {
                addCallWithIntInt(units, s, "StoreAddress", IntConstant.v(0), IntConstant.v(st.get(local.getName())), false);
                //addCallWithLocalValue(units, s, "StoreValue", 1, local, false);
            }
        }
    }


    public void visitConstant(SootMethod sm, Chain units, Stmt s, Constant constant, LocalOrConstantContext context) {
        Type t = constant.getType();
        if (!(t instanceof RefType || t instanceof ArrayType || t instanceof FloatType || t instanceof DoubleType)) {
            if (context == LookupSwitchContextImpl.getInstance() || context == TableSwitchContextImpl.getInstance()) {

            } else if (context == InvokeAndAssignTargetContextImpl.getInstance()
                    || context == InvokeAndAssignArgumentContextImpl.getInstance()
                    || context == InvokeOnlyTargetContextImpl.getInstance()
                    || context == InvokeOnlyArgumentContextImpl.getInstance()) {
                addCallWithLocalValue(units, s, "LoadValue", 2, constant, true);
                addCallWithIntInt(units, s, "LoadArgumentAddress", IntConstant.v(0), IntConstant.v(0), true);
            } else if (context == ReturnContextImpl.getInstance()) {
                addCallWithLocalValue(units, s, "LoadValue", 4, constant, true);
                addCallWithIntInt(units, s, "LoadReturnAddress", IntConstant.v(0), IntConstant.v(0), true);
            } else {
                addCallWithLocalValue(units, s, "LoadValue", 0, constant, true);
                addCallWithIntInt(units, s, "LoadAddress", IntConstant.v(0), IntConstant.v(0), true);
            }
        }
    }

    /*
        C.f = t1;

        to

        LoadValue(iid,0,t1);
        LoadAddress(iid,0,st.get("t1");
        C.f = t1;
        StoreValue(iid);
        StoreAddress(iid,st.get("C"),st.get("f"));

     */

    /*
        t = C.f;

        to

        LoadValue(iid);
        LoadAddress(iid,st.get("C"),st.get("f"));
        t = C.f;
        StoreValue(iid,1,t);
        StoreAddress(iid,0,st.get("t");
     */

    public void visitStaticFieldRef(SootMethod sm, Chain units, Stmt s, StaticFieldRef staticFieldRef, RefContext context) {
        Type t = staticFieldRef.getType();
        if (!(t instanceof RefType || t instanceof ArrayType || t instanceof FloatType || t instanceof DoubleType)) {

            Value v1 = IntConstant.v(st.get(staticFieldRef.getField().getDeclaringClass().getName()));
            Value v2 = IntConstant.v(st.get(staticFieldRef.getField().getName()));
            if (context instanceof RHSContext) {
                addCall(units, s, "LoadValue", true); // just a place holder
                addCallWithIntInt(units, s, "LoadAddress", v1, v2, true);
            } else if (context instanceof LHSContext) {
                addCallWithIntInt(units, s, "StoreAddress", v1, v2, false);
                //addCall(units, s, "StoreValue", false); // just a place holder
            }
        }
    }

    /*
        t[i] = t1;

        to

        LoadValue(iid,0,t1);
        LoadAddress(iid,0,st.get("t1");
        t[i] = t1;
        StoreValue(iid);
        StoreAddress(iid,t,i);

     */

    /*
        t = t1[i];

        to

        LoadValue(iid);
        LoadAddress(iid,t1,i);
        t = t1[i];
        StoreValue(iid,1,t);
        StoreAddress(iid,0,st.get("t");
     */

    public void visitArrayRef(SootMethod sm, Chain units, Stmt s, ArrayRef arrayRef, RefContext context) {
        Type t = arrayRef.getType();
        if (!(t instanceof RefType || t instanceof ArrayType || t instanceof FloatType || t instanceof DoubleType)) {
            if (context instanceof RHSContext) {
                addCall(units, s, "LoadValue", true); // just a place holder
                addCallWithObjectInt(units, s, "LoadAddress", arrayRef.getBase(), arrayRef.getIndex(), true);
            } else if (context instanceof LHSContext) {
                addCallWithObjectInt(units, s, "StoreAddress", arrayRef.getBase(), arrayRef.getIndex(), false);
                addCall(units, s, "StoreValue", false); // just a place holder
            }
        }
    }

    /*
        t.f = t1;

        to

        LoadValue(iid,0,t1);
        LoadAddress(iid,0,st.get("t1");
        t.f = t1;
        StoreValue(iid);
        StoreAddress(iid,t,st.get("f"));

     */

    /*
        t = t1.f;

        to

        LoadValue(iid);
        LoadAddress(iid,t1,st.get("f"));
        t = t1.f;
        StoreValue(iid,1,t);
        StoreAddress(iid,0,st.get("t");
     */

    public void visitInstanceFieldRef(SootMethod sm, Chain units, Stmt s, InstanceFieldRef instanceFieldRef, RefContext context) {
        Type t = instanceFieldRef.getType();
        if (!(t instanceof RefType || t instanceof ArrayType || t instanceof FloatType || t instanceof DoubleType)) {
            Value v = IntConstant.v(st.get(instanceFieldRef.getField().getName()));
            if (context instanceof RHSContext) {
                addCall(units, s, "LoadValue", true); // just a place holder
                addCallWithObjectInt(units, s, "LoadAddress", instanceFieldRef.getBase(), v, true);
            } else if (context instanceof LHSContext) {
                addCallWithObjectInt(units, s, "StoreAddress", instanceFieldRef.getBase(), v, false);
                addCall(units, s, "StoreValue", false); // just a place holder
            }
        }
    }

    public static void addCallWithLocalValue(Chain units, Stmt s, String methodName, int valueType, Value v, boolean before) {
        Type type = v.getType();
        if (type instanceof IntType) {
            addCallWithType(units, s, methodName, IntConstant.v(valueType), v, "int", before);
        } else if (type instanceof LongType) {
            addCallWithType(units, s, methodName, IntConstant.v(valueType), v, "long", before);
        } else if (type instanceof ByteType) {
            addCallWithType(units, s, methodName, IntConstant.v(valueType), v, "byte", before);
        } else if (type instanceof ShortType) {
            addCallWithType(units, s, methodName, IntConstant.v(valueType), v, "short", before);
        } else if (type instanceof CharType) {
            addCallWithType(units, s, methodName, IntConstant.v(valueType), v, "char", before);
        } else if (type instanceof FloatType) {
            addCallWithType(units, s, methodName, IntConstant.v(valueType), v, "float", before);
        } else if (type instanceof DoubleType) {
            addCallWithType(units, s, methodName, IntConstant.v(valueType), v, "double", before);
        } else if (type instanceof BooleanType) {
            addCallWithType(units, s, methodName, IntConstant.v(valueType), v, "boolean", before);
        } else if (type instanceof RefType) {
            addCallWithType(units, s, methodName, IntConstant.v(valueType), v, "java.lang.Object", before);
        } else if (type instanceof ArrayType) {
            addCallWithType(units, s, methodName, IntConstant.v(valueType), v, "java.lang.Object", before);
        } else if (type.toString().equals("null_type")) {
            addCallWithType(units, s, methodName, IntConstant.v(valueType), v, "java.lang.Object", before);
        }
    }

    public static void addCallWithType(Chain units, Stmt s, String methodName, Value v1, Value v2, String typeName, boolean before) {
        SootMethodRef mr;
        LinkedList args = new LinkedList();
        args.addLast(IntConstant.v(getAndIncCounter()));
        args.addLast(v1);
        args.addLast(v2);

        mr = Scene.v().getMethod("<" + observerClass + ": void " + methodName + "(int,int," + typeName + ")>").makeRef();
        if (before) {
            units.insertBefore(Jimple.v().newInvokeStmt(Jimple.v().newStaticInvokeExpr(mr, args)), s);
        } else {
            units.insertAfter(Jimple.v().newInvokeStmt(Jimple.v().newStaticInvokeExpr(mr, args)), s);
        }
    }

}
