/**
 * Copyright (c) 2011, Regents of the University of California
 * All rights reserved.
 * <p/>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * <p/>
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * <p/>
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 * <p/>
 * 3. Neither the name of the University of California, Berkeley nor
 * the names of its contributors may be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 * <p/>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package edu.berkeley.cs.wise.concolic;

import java.io.Serializable;

import edu.berkeley.cs.wise.concolic.solvers.Solution;

/**
 * @author Koushik Sen <ksen@cs.berkeley.edu>
 * @author Jacob Burnim <jburnim@cs.berkeley.edu>
 */
public class BranchHistoryElement extends HistoryElement implements Serializable {
    private boolean branch;
    private boolean done;
    private int index = -1;
    private int iid;

    /* Have we attempted to solve for inputs which negate this branch? */
    private boolean hasSolution = false;

    /* If so, what was the solution?  null indicates the negation is infeasible. */
    private Solution solution = null;


    public BranchHistoryElement(int iid, boolean branch, boolean done) {
        this.branch = branch;
        this.done = done;
        this.iid = iid;
    }


    public boolean getBranch() {
        return branch;
    }

    public void addConstraintIndex(int loc) {
        index = loc;
    }

    public int getConstraintIndex() {
        return index;
    }

    public boolean hasSolution() {
        return hasSolution;
    }

    public void setSolution(Solution soln) {
        hasSolution = true;
        solution = soln;
    }

    public Solution getSolution() {
        return solution;
    }

    public void print() {
        System.out.println("Branch:(" + iid + "," + branch + "," + done + "," + index + ")");
    }

    public void flipBranch() {
        this.branch = !branch;
        this.hasSolution = false;
        this.solution = null;
    }

    public void setDone(boolean b) {
        done = b;
    }

    public boolean isDone() {
        return done;
    }


    public String toString() {
        return branch ? "T" : "F";
    }

    public HistoryElement makeCopy() {
        BranchHistoryElement ret = new BranchHistoryElement(iid, branch, done);
        ret.index = index;
        return ret;
    }

//    public void printTrace(PrintStream out, String s, ArrayList<String> iidToLineMap) {
//        out.print(s);
//        if (branch) {
//            out.println("<a href=\"tmpclasses/" + iidToLineMap.get(iid) + "\">" + iid + ":T</a><br>");
//        } else {
//            out.println("<a href=\"tmpclasses/" + iidToLineMap.get(iid) + "\">" + iid + ":F</a><br>");
//        }
//    }

    public int getIid() {
        return iid;
    }
}
