/**
 * Copyright (c) 2011, Regents of the University of California
 * All rights reserved.
 * <p/>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * <p/>
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * <p/>
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 * <p/>
 * 3. Neither the name of the University of California, Berkeley nor
 * the names of its contributors may be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 * <p/>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package edu.berkeley.cs.wise.concolic;

import edu.berkeley.cs.wise.observer.Observer;

/**
 * @author Koushik Sen <ksen@cs.berkeley.edu>
 * @author Jacob Burnim <jburnim@cs.berkeley.edu>
 */
public class ObserverForConcolic extends Observer {
    public static ThreadLocal eh = new ThreadLocal() {
        protected synchronized Object initialValue() {
            return new ConcolicEventHandler(null);
        }
    };

    public static long Long(long MIN, long MAX, long defaultVal) {
        ((ConcolicEventHandler) eh.get()).MakeSymbolic(MIN, MAX);
        return ((ConcolicEventHandler) eh.get()).GetInput(MIN, MAX, defaultVal);
    }

    public static int Integer(int MIN, int MAX, long defaultVal) {
        ((ConcolicEventHandler) eh.get()).MakeSymbolic(MIN, MAX);
        return (int) ((ConcolicEventHandler) eh.get()).GetInput(MIN, MAX, defaultVal);
    }

    public static char Character(char MIN, char MAX, long defaultVal) {
        ((ConcolicEventHandler) eh.get()).MakeSymbolic(MIN, MAX);
        return (char) ((ConcolicEventHandler) eh.get()).GetInput(MIN, MAX, defaultVal);
    }

    public static short Short(short MIN, short MAX, long defaultVal) {
        ((ConcolicEventHandler) eh.get()).MakeSymbolic(MIN, MAX);
        return (short) ((ConcolicEventHandler) eh.get()).GetInput(MIN, MAX, defaultVal);
    }

    public static byte Byte(byte MIN, byte MAX, long defaultVal) {
        ((ConcolicEventHandler) eh.get()).MakeSymbolic(MIN, MAX);
        return (byte) ((ConcolicEventHandler) eh.get()).GetInput(MIN, MAX, defaultVal);
    }

    public static boolean Boolean(long defaultVal) {
        ((ConcolicEventHandler) eh.get()).MakeSymbolic(0, 1);
        return (((ConcolicEventHandler) eh.get()).GetInput(0, 1, defaultVal) != 0);
    }

    public static void LoadValue(int iid, int type, int i) {
        ((ConcolicEventHandler) eh.get()).LoadValue(iid, type, i);
    }

    public static void LoadValue(int iid, int type, long l) {
        ((ConcolicEventHandler) eh.get()).LoadValue(iid, type, l);
    }

    public static void LoadValue(int iid, int type, byte b) {
        ((ConcolicEventHandler) eh.get()).LoadValue(iid, type, b);
    }

    public static void LoadValue(int iid, int type, short s) {
        ((ConcolicEventHandler) eh.get()).LoadValue(iid, type, s);
    }

    public static void LoadValue(int iid, int type, char c) {
        ((ConcolicEventHandler) eh.get()).LoadValue(iid, type, c);
    }

    public static void LoadValue(int iid, int type, float f) {
    }

    public static void LoadValue(int iid, int type, double d) {
    }

    public static void LoadValue(int iid, int type, boolean b) {
        ((ConcolicEventHandler) eh.get()).LoadValue(iid, type, b);
    }

    public static void LoadValue(int iid, int type, Object o) {
    }

    public static void LoadValue(int iid) {
    }

    public static void StoreValue(int iid, int type, int i) {

    }

    public static void StoreValue(int iid, int type, long l) {

    }

    public static void StoreValue(int iid, int type, byte b) {

    }

    public static void StoreValue(int iid, int type, short s) {

    }

    public static void StoreValue(int iid, int type, char c) {

    }

    public static void StoreValue(int iid, int type, float f) {

    }

    public static void StoreValue(int iid, int type, double d) {

    }

    public static void StoreValue(int iid, int type, boolean b) {

    }

    public static void StoreValue(int iid, int type, Object o) {

    }

    public static void StoreValue(int iid) {

    }


    public static void LoadAddress(int iid, int i, int f) {
        ((ConcolicEventHandler) eh.get()).LoadAddress(iid, id(i, f));
    }

    public static void LoadAddress(int iid, Object o, int f) {
        ((ConcolicEventHandler) eh.get()).LoadAddress(iid, id(o, f));
    }

    public static void LoadReturnAddress(int iid, int i, int f) {
        ((ConcolicEventHandler) eh.get()).LoadReturnAddress(iid, id(i, f));
    }

    public static void LoadArgumentAddress(int iid, int i, int f) {
        ((ConcolicEventHandler) eh.get()).LoadArgumentAddress(iid, id(i, f));
    }


    public static void StoreAddress(int iid, int i, int f) {
        ((ConcolicEventHandler) eh.get()).StoreAddress(iid, id(i, f));
    }

    public static void StoreAddress(int iid, Object o, int f) {
        ((ConcolicEventHandler) eh.get()).StoreAddress(iid, id(o, f));
    }

    public static void StoreReturnAddress(int iid, int i, int f) {
        ((ConcolicEventHandler) eh.get()).StoreReturnAddress(iid, id(i, f));
    }

    public static void StoreArgumentAddress(int iid, int i, int f) {
        ((ConcolicEventHandler) eh.get()).StoreArgumentAddress(iid, id(i, f));
    }

    public static void ApplyOp(int iid, Object op) {
        ((ConcolicEventHandler) eh.get()).ApplyOp(iid, (String) op);
    }

    public static void ApplyOp(int iid, Object op, String type) {
        ((ConcolicEventHandler) eh.get()).ApplyOp(iid, (String) op, type);
    }

    public static void MethodCall(int iid, Object sig) {
        ((ConcolicEventHandler) eh.get()).MethodCall(iid, (String) sig);
    }

    public static void MethodReturn(int iid, Object sig) {
        ((ConcolicEventHandler) eh.get()).MethodReturn(iid, (String) sig);
    }

    public static void PrepareMethodCall(int iid) {
        ((ConcolicEventHandler) eh.get()).PrepareMethodCall(iid);

    }

    public static void BranchThen(int iid, int bid) {
        ((ConcolicEventHandler) eh.get()).BranchThen(iid, bid);
    }

    public static void BranchElse(int iid, int bid) {
        ((ConcolicEventHandler) eh.get()).BranchElse(iid, bid);
    }

    public static void ResetBranchCounting() {
        ((ConcolicEventHandler) eh.get()).ResetBranchCounting();
    }

    public static boolean SolveAndReset() {
        return ((ConcolicEventHandler) eh.get()).SolveAndReset();
    }

    public static void SetMode(int i) {
        ((ConcolicEventHandler) eh.get()).SetMode(i);
    }

    public static void Initialize() {
        ((ConcolicEventHandler) eh.get()).Initialize();
    }

    public static void Shutdown() {
        ((ConcolicEventHandler) eh.get()).Shutdown();
    }

    public static History CreateTask() {
        return ((ConcolicEventHandler) eh.get()).SolveToCreateTask();
    }
}
