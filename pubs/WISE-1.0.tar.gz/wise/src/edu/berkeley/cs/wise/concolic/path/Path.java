/**
 * Copyright (c) 2011, Regents of the University of California
 * All rights reserved.
 * <p/>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * <p/>
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * <p/>
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 * <p/>
 * 3. Neither the name of the University of California, Berkeley nor
 * the names of its contributors may be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 * <p/>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package edu.berkeley.cs.wise.concolic.path;

import edu.berkeley.cs.wise.concolic.Branch;
import edu.berkeley.cs.wise.concolic.BranchHistoryElement;
import edu.berkeley.cs.wise.concolic.CallHistoryElement;
import edu.berkeley.cs.wise.concolic.History;
import edu.berkeley.cs.wise.concolic.HistoryElement;

import java.io.PrintStream;
import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * @author Koushik Sen <ksen@cs.berkeley.edu>
 * @author Jacob Burnim <jburnim@cs.berkeley.edu>
 */
public class Path implements Serializable {
    private int branchCount;
    private ArrayList<PathNode> root;

    public Path() {
        root = new ArrayList<PathNode>();
        branchCount = 0;
    }

    public void populateTrace(History history) {
        Iterator iter = history.iterator();
        populateTrace(this, this.root, iter);
    }

    private static void populateTrace(Path t,
                                      ArrayList<PathNode> nodes,
                                      Iterator<HistoryElement> iter) {
        while (iter.hasNext()) {
            HistoryElement elem = iter.next();

            if (elem instanceof BranchHistoryElement) {
                BranchHistoryElement be = (BranchHistoryElement)elem;
                nodes.add(new BranchPathNode(be.getIid(), be.getBranch()));
                t.incBranchCount();

            } else if (elem instanceof CallHistoryElement) {
                CallHistoryElement ce = (CallHistoryElement)elem;
                if (ce.isEntry()) {
                    CallPathNode call = new CallPathNode(ce.getIid());
                    nodes.add(call);
                    populateTrace(t, call.getBodyNodes(), iter);
                } else {
                    return;
                }
            }
        }
    }

    public void incBranchCount() {
        branchCount++;
    }

    public int getBranchCount() {
        return branchCount;
    }

    public void printTrace(PrintStream out, ArrayList<String> iidToLineMap) {
        printTrace(out, root, "", iidToLineMap);
    }

    public void printTrace() {
        printTrace(root, "");
    }

    public void printTrace(ArrayList<PathNode> nodes, String space) {
        for (PathNode n : nodes) {
            if (n instanceof BranchPathNode) {
                BranchPathNode bNode = (BranchPathNode)n;
                System.out.print(space);
                if (bNode.isBranch()) {
                    System.out.println(bNode.getIid() + ":T");
                } else {
                    System.out.println(bNode.getIid() + ":F");
                }
            } else if (n instanceof CallPathNode) {
                CallPathNode cNode = (CallPathNode) n;
                System.out.println(cNode.getIid() + ":(");
                printTrace(cNode.getBodyNodes(), space + "      ");
            }
        }
    }

    public void printTrace(PrintStream out,
                           ArrayList<PathNode> nodes,
                           String space,
                           ArrayList<String> iidToLineMap) {

        for (PathNode n : nodes) {
            if (n instanceof BranchPathNode) {
                BranchPathNode bNode = (BranchPathNode)n;
                out.print(space);
                if (bNode.isBranch()) {
                    out.println("<a href=\"tmpclasses/"
                                + iidToLineMap.get(bNode.getIid()) + "\">"
                                + bNode.getIid() + ":T</a><br>");
                } else {
                    out.println("<a href=\"tmpclasses/"
                                + iidToLineMap.get(bNode.getIid()) + "\">"
                                + bNode.getIid() + ":F</a><br>");
                }
            } else if (n instanceof CallPathNode) {
                CallPathNode cNode = (CallPathNode) n;
                out.print(space);
                out.println("<a href=\"tmpclasses/"
                            + iidToLineMap.get(cNode.getIid()) + "\">("
                            + cNode.getIid() + "</a><br>");
                printTrace(out,
                           cNode.getBodyNodes(),
                           space + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",
                           iidToLineMap);
                out.print(space);
                out.println("<a href=\"tmpclasses/"
                            + iidToLineMap.get(cNode.getIid()) + "\">"
                            + cNode.getIid() + ")</a><br>");
            }
        }
    }

    public void setBranchCount(int branchCount) {
        this.branchCount = branchCount;
    }
}
