/**
 * Copyright (c) 2011, Regents of the University of California
 * All rights reserved.
 * <p/>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * <p/>
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * <p/>
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 * <p/>
 * 3. Neither the name of the University of California, Berkeley nor
 * the names of its contributors may be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 * <p/>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package edu.berkeley.cs.wise.concolic;

import edu.berkeley.cs.wise.concolic.solvers.Solution;

import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;

/**
 * @author Koushik Sen <ksen@cs.berkeley.edu>
 * @author Jacob Burnim <jburnim@cs.berkeley.edu>
 */
public class History implements Comparator {
    private ArrayList<HistoryElement> history;
    private ArrayList<InputHistoryElement> inputs;
    private int historyCounter;
    private boolean predictionFailed;
    private int branchCount;
    private int priority;


    public History() {
        history = new ArrayList<HistoryElement>(1000);
        inputs = new ArrayList<InputHistoryElement>(100);
        historyCounter = 0;
        predictionFailed = false;
        branchCount = 0;
    }

    public void reset() {
        inputs.clear();
        historyCounter = 0;
        predictionFailed = false;
        branchCount = 0;
    }

    public void restart() {
        reset();
        history.clear();
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public static History readHistory() {
        History ret = new History();
        ObjectInputStream in = null;
        try {
            in = new ObjectInputStream(new BufferedInputStream(new FileInputStream(Globals.historyFile)));
            ret.history = (ArrayList<HistoryElement>) in.readObject();
            in.close();
            return ret;
        } catch (IOException e) {
            return new History();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return new History();
        }
    }

    public void writeHistory() {
        ObjectOutputStream out;
        try {
            out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(Globals.historyFile)));
            out.writeObject(history);
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
            Runtime.getRuntime().halt(1);
        }
    }

    private boolean historyAvailable() {
        return historyCounter < history.size();
    }

    private void addToHistory(HistoryElement h) {
        history.add(h);
        historyCounter++;
    }

    private HistoryElement nextHistory() {
        System.out.flush();
        return history.get(historyCounter++);
    }

    private boolean match(HistoryElement e, int iid) {
        if (e instanceof BranchHistoryElement) {
            return ((BranchHistoryElement) e).getIid() == iid;
        } else if (e instanceof CallHistoryElement) {
            return ((CallHistoryElement) e).getIid() == iid;
        } else if (e instanceof InputHistoryElement) {
            return iid == -1;
        } else {
            return false;
        }
    }


    public BranchHistoryElement getBranchAt(int i) {
        HistoryElement elem = history.get(i);
        if (elem instanceof BranchHistoryElement) {
            return (BranchHistoryElement) elem;
        } else {
            return null;
        }
    }

    public void flipBranchAndSetDoneAt(int i) {
        historyCounter = i + 1;
        int sz = history.size();
        for (int j = sz - 1; j >= historyCounter; j--) {
            history.remove(j);
        }
        BranchHistoryElement elem = (BranchHistoryElement) history.get(i);
        elem.flipBranch();
        elem.setDone(true);
    }

    public History makeCopy() {
        History tmp = new History();
        int sz = history.size();
        for (int j = 0; j < sz; j++) {
            HistoryElement e = history.get(j).makeCopy();
            tmp.addToHistory(e);
            if (e instanceof InputHistoryElement) {
                tmp.inputs.add((InputHistoryElement) e);
            }
        }
        return tmp;
    }

    public void addCallToHistory(int iid, boolean isEntry) {
        if (!historyAvailable()) {
            CallHistoryElement ce = new CallHistoryElement(iid, isEntry);
            addToHistory(ce);
        } else {
            HistoryElement e = nextHistory();
            if (!match(e, iid)) {
                addCallToHistory(iid, isEntry);
            }
        }
    }

    public long addAndReturnInput(long MIN, long MAX, long defaultVal) {
        InputHistoryElement i;
        if (historyAvailable()) {
            // TODO(jburnim): Do we need to check here that the available
            // input is in the right range (i.e. [MIN, MAX])?
            i = (InputHistoryElement) nextHistory();
            if (!match(i, -1)) {
                return addAndReturnInput(MIN, MAX, defaultVal);
            }

        } else if (Globals.randomizeInputs) {
            i = new InputHistoryElement(Globals.randomValue(MIN, MAX));

        } else {
            if ((MIN <= defaultVal) && (defaultVal <= MAX)) {
                i = new InputHistoryElement(defaultVal);
            } else {
                i = new InputHistoryElement(MIN);
            }
            addToHistory(i);
        }
        inputs.add(i);
        return i.getLong();
    }


    public void addConstraintAndCheckBranch(int iid, Expression e,
                                            int loc, boolean thenORelse) {
        BranchHistoryElement b;
        branchCount++;

        // Ugly hack to speed up random testing.
        if (Globals.mode == Globals.PERF_RANDOM_MODE)
            return;

        if (historyAvailable()) {
            b = (BranchHistoryElement) nextHistory();
            if (!match(b, iid)) {
                addConstraintAndCheckBranch(iid, e, loc, thenORelse);
                return;
            }
            if (b.getBranch() != thenORelse) {
                System.err.println("Prediction failed! Exiting");
                predictionFailed = true;
                System.exit(1);
            }
        } else {
            b = new BranchHistoryElement(iid, thenORelse, false);
            addToHistory(b);
        }
        b.addConstraintIndex(loc);
    }

    public void setInputFromYicesOutput(String line) {
        if (line.startsWith("(")) {
            String[] tokens = line.split(" ");
            int xi = Integer.parseInt(tokens[1].substring(1));
            String tmp = tokens[2].trim();
            long val = Long.parseLong(tmp.substring(0, tmp.length() - 1));
            inputs.get(xi).setLong(val);
        }
    }

    public void print() {
        System.out.println("Printing History:");
        System.out.println("-----------------");
        int i = 0;
        for (HistoryElement historyElement : history) {
            System.out.print(i + ":");
            i++;
            historyElement.print();
        }
        System.out.println("-----------------");
    }


    public Iterator<HistoryElement> iterator() {
        return history.iterator();
    }

    public void ResetBranchCounting() {
        branchCount = 0;
    }

    public boolean isPredictionFailed() {
        return predictionFailed;
    }

    public int size() {
        return history.size();
    }

    public int getNumInputs() {
        return inputs.size();
    }

    public int getBranchCount() {
        return branchCount;
    }

    public void writeInputs() {
        PrintStream out;
        try {
            out = new PrintStream(new BufferedOutputStream(new FileOutputStream(Globals.lastInputFile)));
            for (HistoryElement historyElement : history) {
                if (historyElement instanceof InputHistoryElement)
                    out.println(((InputHistoryElement) historyElement).getLong());
            }
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
            Runtime.getRuntime().halt(1);
        }
    }

    public HistoryElement getElementAt(int i) {
        return history.get(i);
    }

    public int compare(Object o1, Object o2) {
        return ((History) o1).priority - ((History) o2).priority;
    }

    public void setDoneAt(int i) {
        ((BranchHistoryElement) history.get(i)).setDone(true);
    }

    public void setInput(int i, long l) {
        if ((i >= 0) && (i < inputs.size())) {
            inputs.get(i).setLong(l);
        }
    }

    public void setInputs(Solution soln) {
        for (Map.Entry<Integer, Long> e : soln.soln.entrySet()) {
            setInput(e.getKey(), e.getValue());
        }
    }

    public Solution getInputs() {
        Solution ret = new Solution();
        for (int i = 0; i < inputs.size(); i++) {
            ret.setVar(i, inputs.get(i).getLong());
        }
        return ret;
    }
}
