/**
 * Copyright (c) 2011, Regents of the University of California
 * All rights reserved.
 * <p/>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * <p/>
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * <p/>
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 * <p/>
 * 3. Neither the name of the University of California, Berkeley nor
 * the names of its contributors may be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 * <p/>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package edu.berkeley.cs.wise.observer;

import edu.berkeley.cs.wise.utils.Parameters;
import edu.berkeley.cs.wise.utils.WeakIdentityHashMap;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

/**
 * @author Koushik Sen <ksen@cs.berkeley.edu>
 * @author Pallavi Joshi <pallavi@cs.berkeley.edu>
 */
public class Observer {

    private static WeakIdentityHashMap objectMap = new WeakIdentityHashMap();
    private static int currentId = Parameters.readInteger(Parameters.usedIdFile, 0);
    private static boolean debug = Parameters.DEBUG;

    public static long id(int f, int s) {
        long l = f;
        l = l << 32;
        l += s;
        return l;
    }

    public static ArrayList<String> getIidToLineMap(String file) {
        ObjectInputStream in;
        ArrayList<String> ret;
        try {
            in = new ObjectInputStream(new BufferedInputStream(new FileInputStream(file)));
            ret = (ArrayList<String>) in.readObject();
            in.close();
            return ret;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    synchronized public static int uniqueId(Object o) {
        Object val = objectMap.get(o);
        if (val == null) {
            val = currentId++;
            objectMap.put(o, val);
        }
        return (Integer) val;
    }

    synchronized public static Object idToObject(int id) {
        for (Object ret : objectMap.keySet()) {
            Integer val = (Integer) objectMap.get(ret);
            if (val != null) {
                if (val == id)
                    return ret;
            }
        }
        return "Unknown Object";
    }

    public static long id(Object o, int x) {
        // We must add 1 below so that we never assign to a field an
        // identifier smaller than (1 << 32).
        return id(uniqueId(o)+1, x);
    }

    public static void logme(String fname, boolean startOrEnd) {
        logme(fname, startOrEnd, Thread.currentThread());
    }

    public static void logme(String fname, boolean startOrEnd, Thread td) {
        if (!debug) return;
        Throwable t = new Throwable();
        StackTraceElement[] elems = t.getStackTrace();
        System.out.print("(");
        System.out.print(elems[3].getFileName());
        System.out.print(":");
        System.out.print(elems[3].getLineNumber());
        System.out.print(")");
        System.out.print(":");
        System.out.print(fname);
        System.out.print(":");
        System.out.print(td.getName());
        System.out.print(":");
        if (startOrEnd) {
            System.out.println(">>>");
        } else {
            System.out.println("<<<");
        }
    }

}
