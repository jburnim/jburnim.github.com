/**
 * Copyright (c) 2011, Regents of the University of California
 * All rights reserved.
 * <p/>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * <p/>
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * <p/>
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 * <p/>
 * 3. Neither the name of the University of California, Berkeley nor
 * the names of its contributors may be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 * <p/>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package edu.berkeley.cs.wise.concolic;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;
import java.util.TreeSet;
import java.util.Queue;

/**
 * @author Koushik Sen <ksen@cs.berkeley.edu>
 * @author Jacob Burnim <jburnim@cs.berkeley.edu>
 */
public class PathConstraint {
    private ArrayList<Expression> pathConstraint;
    private HashSet<Expression> constraintSet;

    public PathConstraint() {
        pathConstraint = new ArrayList<Expression>(1000);
        constraintSet = new HashSet<Expression>(1000);
    }

    public int addConstraint(Expression e) {
        if ((e != null) && constraintSet.add(e)) {
            pathConstraint.add(e);
            return pathConstraint.size() - 1;
        } else {
            return -1;
        }
    }

    public void print() {
        System.out.println("Path Constraint:");
        System.out.println("----------------");
        for (Expression expression : pathConstraint) {
            System.out.println(expression);
        }
        System.out.println("----------------");
    }

    /*
     * Returns a new PathConstraint containing only the constraints
     * with index 0 to n and which are dependent on constraint n.
     */
    public PathConstraint dependentConstraints(int n, int nInputs) {
        // Build a graph on the variables, indicating a dependence
        // when two variables co-occur in a symbolic predicate.
        Set<Integer> depends[] = new Set[nInputs];
        for (int i = 0; i < nInputs; i++) {
            depends[i] = new TreeSet<Integer>();
        }
        for (int i = 0; i <= n; i++) {
            Collection<Integer> inputs = pathConstraint.get(i).getInputs();
            for (int v : inputs) {
                depends[v].addAll(inputs);
            }
        }

        // Run a BFS to determine which variables may be dependent on
        // the new constraint.
        Set<Integer> dependentVars =
            new TreeSet<Integer>(pathConstraint.get(n).getInputs());
        Queue<Integer> Q = new LinkedList<Integer>(dependentVars);
        while (!Q.isEmpty()) {
            for (int v : depends[Q.remove()]) {
                if (dependentVars.add(v)) {
                    Q.add(v);
                }
            }
        }

        // Construct a PathConstraint with the dependent constraints.
        PathConstraint ret = new PathConstraint();
        for (int i = 0; i <= n; i++) {
            Expression c = pathConstraint.get(i);
            if (dependentVars.containsAll(c.getInputs())) {
                ret.addConstraint(c);
            } else {
                c.print(System.out);
                System.out.println();
            }
        }
        return ret;
    }

    public void sendFormulaToYicesSolver(PrintStream out, int n, int nInputs) {
        out.println("(set-evidence! true)");
        for (int i = 0; i < nInputs; i++) {
            out.print("(define x");
            out.print(i);
            out.println("::int)");
        }
        for (int i = 0; i < n; i++) {
            out.print("(assert ");
            pathConstraint.get(i).print(out);
            out.print(")");
        }
        out.print("(assert (not ");
        pathConstraint.get(n).print(out);
        out.print("))");
        out.println("(check)");
    }

    public void reset() {
        pathConstraint.clear();
        constraintSet.clear();
    }

    public boolean isEmpty() {
        return pathConstraint.isEmpty();
    }

    public int size() {
        return pathConstraint.size();
    }
}
