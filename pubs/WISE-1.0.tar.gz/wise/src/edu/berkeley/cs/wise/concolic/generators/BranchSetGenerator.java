/**
 * Copyright (c) 2011, Regents of the University of California
 * All rights reserved.
 * <p/>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * <p/>
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * <p/>
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 * <p/>
 * 3. Neither the name of the University of California, Berkeley nor
 * the names of its contributors may be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 * <p/>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package edu.berkeley.cs.wise.concolic.generators;

import java.util.Collections;
import java.util.Set;
import java.util.TreeSet;
import edu.berkeley.cs.wise.concolic.Branch;
import edu.berkeley.cs.wise.concolic.BranchHistoryElement;
import edu.berkeley.cs.wise.concolic.History;

/**
 * @author Jacob Burnim <jburnim@cs.berkeley.edu>
 */
public class BranchSetGenerator
    implements Generator, BoundedJoinSemilattice<BranchSetGenerator> {

    public static class Factory implements GeneratorFactory<BranchSetGenerator> {
        public BranchSetGenerator makeGenerator(History hist) {
            return new BranchSetGenerator(hist);
        }
    }

    private static final BranchSetGenerator bottom =
        new BranchSetGenerator(Collections.<Branch>emptySet());

    // TODO(jburnim): Figure out the right interface for having
    // generators guide concolic search.
    final public Set<Branch> branchSet;

    BranchSetGenerator(Set<Branch> bs) {
        branchSet = bs;
    }

    BranchSetGenerator(History hist) {
        branchSet = new TreeSet<Branch>();
        for (int i = 0; i < hist.size(); i++) {
            BranchHistoryElement e = hist.getBranchAt(i);
            if (e != null) {
                branchSet.add(new Branch(e.getIid(), e.getBranch()));
            }
        }
    }

    public String toString() {
	String ret = "";
	for (Branch b : branchSet) {
	    ret = ret + b + " ";
	}
	return ret;
    }

    public boolean isLessThan(BranchSetGenerator bsg) {
        return (this.isLessThanOrEqualTo(bsg) && !this.equals(bsg));
    }

    public boolean isLessThanOrEqualTo(BranchSetGenerator bsg) {
        return bsg.branchSet.containsAll(this.branchSet);
    }

    public BranchSetGenerator join(BranchSetGenerator bsg) {
        if (bsg.isLessThanOrEqualTo(this)) {
            return this;
        } else if (this.isLessThanOrEqualTo(bsg)) {
            return bsg;
        }

        Set<Branch> bs = new TreeSet<Branch>(branchSet);
        bs.addAll(bsg.branchSet);
        return new BranchSetGenerator(bs);
    }

    public BranchSetGenerator getBottomElement() {
        return bottom;
    }

    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null)
            return false;
        if (this.getClass() != o.getClass())
            return false;

        BranchSetGenerator g = (BranchSetGenerator)o;
        return this.branchSet.equals(g.branchSet);
    }

    public int hashCode() {
        return this.branchSet.hashCode();
    }

    // public int findFirstIllegalBranch(History h) {
    //     for (int i = 0; i < h.size(); i++) {
    //         BranchHistoryElement e = h.getBranchAt(i);
    //         if (e == null)
    //             continue;
    //         Branch b = new Branch(e.getIid(), e.getBranch());
    //         if (!branchSet.contains(b)) {
    //             return i;
    //         }
    //     }
    //     return -1;
    // }
}
