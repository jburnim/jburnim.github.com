/**
 * Copyright (c) 2011, Regents of the University of California
 * All rights reserved.
 * <p/>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * <p/>
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * <p/>
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 * <p/>
 * 3. Neither the name of the University of California, Berkeley nor
 * the names of its contributors may be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 * <p/>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package edu.berkeley.cs.wise.concolic;

import edu.berkeley.cs.wise.concolic.generators.BranchSetGenerator;
import edu.berkeley.cs.wise.concolic.generators.Generator;
import edu.berkeley.cs.wise.concolic.generators.BranchPolicyGenerator;
import edu.berkeley.cs.wise.concolic.generators.TrivialGenerator;
import edu.berkeley.cs.wise.concolic.path.MaxPaths;

import java.util.Random;

/**
 * @author Koushik Sen <ksen@cs.berkeley.edu>
 * @author Jacob Burnim <jburnim@cs.berkeley.edu>
 */
public class Globals {

    /*
     * Generates a random long from [MIN, MAX], using the global RNG.
     */
    public static long randomValue(long MIN, long MAX) {
        if ((MIN == Long.MIN_VALUE) && (MAX == Long.MAX_VALUE))
            return random.nextLong();

        long length = MAX - MIN;  // Cannot overflow to zero.
        long shift = Long.numberOfLeadingZeros(length);
        while (true) {
            long r = random.nextLong() >>> shift;
            if (r <= length) {
                return MIN + r;
            }
        }
    }

    public static final int FAST_DEFAULT_MODE = 1;
    public static final int PERSIST_MODE = 2;

    // Performance-directed testing with branch sets.
    public static final int PERF_BRANCH_SET_FIND_MODE = 3;
    public static final int PERF_BRANCH_SET_SOLVE_MODE = 4;

    // Performance-directed testing with three-way branch sets.
    public static final int PERF_BRANCH_POLICY_FIND_MODE = 5;
    public static final int PERF_BRANCH_POLICY_SOLVE_MODE = 6;

    // Performance-directed random testing.
    public static final int PERF_RANDOM_MODE = 7;

    // If given, instead of selecting the first maximal generator that
    // generates the fewest paths, select the maximal generator with
    // the given index.
    public static final int generatorIndexToSelect =
        Integer.getInteger("concolic.generator.override.index", -1);

    public static final boolean joinWithPrevGenerator =
        Boolean.getBoolean("concolic.generator.join");

    public static final String yicesCommand =
        System.getProperty("concolic.yices", "yices");

    public static final String maxHistoryFileNamePrefix = "concolic.history.max.";
    public static final String historyFile = "concolic.history";
    public static final String lastInputFile = "concolic.input.last";
    public static final String generatorFile = "concolic.generator";
    public static final String summariesFile = "concolic.summaries";

    public static MaxPaths<? extends Generator> max;
    public static int mode = PERSIST_MODE;

    public static boolean randomizeInputs = false;
    public static final Random random;

    static {
        // Seed the random number generator.
        String seed = System.getProperty("concolic.randomseed");
        Random rng;
        if (seed != null) {
            try {
                rng = new Random(Integer.parseInt(seed));
            } catch (NumberFormatException e) {
                rng = new Random();
            }
        } else {
            rng = new Random();
        }
        random = rng;
    }

    public static void initialize() {
        switch (mode) {
            case PERF_BRANCH_SET_FIND_MODE:
                max = new MaxPaths<BranchSetGenerator>(new BranchSetGenerator.Factory());
                break;
            case PERF_BRANCH_POLICY_FIND_MODE:
                max = new MaxPaths<BranchPolicyGenerator>(new BranchPolicyGenerator.Factory());
                break;
            default:
                max = new MaxPaths<TrivialGenerator>(new TrivialGenerator.Factory());
        }

        randomizeInputs = (mode == PERF_RANDOM_MODE);
    }
}
