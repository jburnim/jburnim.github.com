/**
 * Copyright (c) 2011, Regents of the University of California
 * All rights reserved.
 * <p/>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * <p/>
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * <p/>
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 * <p/>
 * 3. Neither the name of the University of California, Berkeley nor
 * the names of its contributors may be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 * <p/>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package edu.berkeley.cs.wise.concolic;

import edu.berkeley.cs.wise.instrumentor.Visitor;
import edu.berkeley.cs.wise.instrumentor.contexts.*;
import soot.*;
import soot.jimple.*;
import soot.jimple.internal.JCaughtExceptionRef;
import soot.util.Chain;

import java.util.LinkedList;

/**
 * @author Koushik Sen <ksen@cs.berkeley.edu>
 * @author Jacob Burnim <jburnim@cs.berkeley.edu>
 */
public class VisitorForRandom extends Visitor {
    private int branchCount = 0;

    public VisitorForRandom(Visitor nextVisitor) {
        super(nextVisitor);
    }

    public void visitStmt(SootMethod sm, Chain units, Stmt s) {
        nextVisitor.visitStmt(sm, units, s);
    }


    /*
       if (p) goto L;

       to

       if (p) goto L2;
       BranchElse(iid,bid+1);
       goto L1;
       L2: BranchThen(iid,bid);
       L1: nop;
       if (p) goto L;
    */
    public void visitStmtIf(SootMethod sm, Chain units, IfStmt ifStmt) {
        SootMethodRef mr;
        mr = Scene.v().getMethod("<" + observerClass + ": void " + "BranchThen" + "(int,int)>").makeRef();
        Stmt pos = Jimple.v().newInvokeStmt(Jimple.v().newStaticInvokeExpr(mr, IntConstant.v(getAndIncCounter()),
                IntConstant.v(branchCount++)));
        IfStmt is = Jimple.v().newIfStmt(ifStmt.getCondition(), pos);
        units.insertBefore(is, ifStmt);

        mr = Scene.v().getMethod("<" + observerClass + ": void " + "BranchElse" + "(int,int)>").makeRef();
        Stmt neg = Jimple.v().newInvokeStmt(Jimple.v().newStaticInvokeExpr(mr, IntConstant.v(getAndIncCounter()),
                IntConstant.v(branchCount++)));
        units.insertBefore(neg, ifStmt);

        NopStmt ns = Jimple.v().newNopStmt();
        units.insertBefore(Jimple.v().newGotoStmt(ns), ifStmt);
        units.insertBefore(pos, ifStmt);
        units.insertBefore(ns, ifStmt);
    }


    public void visitStmtLookupSwitch(SootMethod sm, Chain units,
                                      LookupSwitchStmt lookupSwitchStmt) {

        int sz = lookupSwitchStmt.getTargetCount();
        NopStmt ns = Jimple.v().newNopStmt();
        LinkedList linkedList = new LinkedList();
        for (int i = 0; i < sz; i++) {
            EqExpr eq = Jimple.v().newEqExpr(lookupSwitchStmt.getKey(), IntConstant.v(lookupSwitchStmt.getLookupValue(i)));
            SootMethodRef mr;
            mr = Scene.v().getMethod("<" + observerClass + ": void " + "BranchThen" + "(int,int)>").makeRef();
            Stmt pos = Jimple.v().newInvokeStmt(Jimple.v().newStaticInvokeExpr(mr, IntConstant.v(getAndIncCounter()),
                    IntConstant.v(branchCount++)));

            mr = Scene.v().getMethod("<" + observerClass + ": void " + "BranchElse" + "(int,int)>").makeRef();
            Stmt neg = Jimple.v().newInvokeStmt(Jimple.v().newStaticInvokeExpr(mr, IntConstant.v(getAndIncCounter()),
                    IntConstant.v(branchCount++)));

            visitBinopExpr(sm, units, lookupSwitchStmt, eq, IfContextImpl.getInstance());
            IfStmt ifStmt = Jimple.v().newIfStmt(eq, pos);
            units.insertBefore(ifStmt, lookupSwitchStmt);
            units.insertBefore(neg, lookupSwitchStmt);
            linkedList.addLast(pos);
        }
        units.insertBefore(Jimple.v().newGotoStmt(ns), lookupSwitchStmt);
        for (Object pos1 : linkedList) {
            Stmt stmt = (Stmt) pos1;
            units.insertBefore(stmt, lookupSwitchStmt);
            units.insertBefore(Jimple.v().newGotoStmt(ns), lookupSwitchStmt);
        }
        units.insertBefore(ns, lookupSwitchStmt);
    }


    public void visitStmtTableSwitch(SootMethod sm, Chain units,
                                     TableSwitchStmt tableSwitchStmt) {

        int sz = tableSwitchStmt.getHighIndex();
        NopStmt ns = Jimple.v().newNopStmt();
        LinkedList linkedList = new LinkedList();
        for (int i = tableSwitchStmt.getLowIndex(); i < sz; i++) {
            EqExpr eq = Jimple.v().newEqExpr(tableSwitchStmt.getKey(), IntConstant.v(i));
            SootMethodRef mr;
            mr = Scene.v().getMethod("<" + observerClass + ": void " + "BranchThen" + "(int,int)>").makeRef();
            Stmt pos = Jimple.v().newInvokeStmt(Jimple.v().newStaticInvokeExpr(mr, IntConstant.v(getAndIncCounter()),
                    IntConstant.v(branchCount++)));

            mr = Scene.v().getMethod("<" + observerClass + ": void " + "BranchElse" + "(int,int)>").makeRef();
            Stmt neg = Jimple.v().newInvokeStmt(Jimple.v().newStaticInvokeExpr(mr, IntConstant.v(getAndIncCounter()),
                    IntConstant.v(branchCount++)));

            visitBinopExpr(sm, units, tableSwitchStmt, eq, IfContextImpl.getInstance());
            IfStmt ifStmt = Jimple.v().newIfStmt(eq, pos);
            units.insertBefore(ifStmt, tableSwitchStmt);
            units.insertBefore(neg, tableSwitchStmt);
            linkedList.addLast(pos);
        }
        units.insertBefore(Jimple.v().newGotoStmt(ns), tableSwitchStmt);
        for (Object pos1 : linkedList) {
            Stmt stmt = (Stmt) pos1;
            units.insertBefore(stmt, tableSwitchStmt);
            units.insertBefore(Jimple.v().newGotoStmt(ns), tableSwitchStmt);
        }
        units.insertBefore(ns, tableSwitchStmt);
    }
}
