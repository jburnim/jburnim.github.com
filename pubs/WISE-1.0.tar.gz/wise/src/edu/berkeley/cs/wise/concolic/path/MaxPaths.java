/**
 * Copyright (c) 2011, Regents of the University of California
 * All rights reserved.
 * <p/>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * <p/>
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * <p/>
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 * <p/>
 * 3. Neither the name of the University of California, Berkeley nor
 * the names of its contributors may be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 * <p/>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package edu.berkeley.cs.wise.concolic.path;

import edu.berkeley.cs.wise.concolic.Globals;
import edu.berkeley.cs.wise.concolic.History;
import edu.berkeley.cs.wise.concolic.generators.Generator;
import edu.berkeley.cs.wise.concolic.generators.GeneratorFactory;
import edu.berkeley.cs.wise.concolic.generators.BoundedJoinSemilattice;
import edu.berkeley.cs.wise.utils.Parameters;

import java.io.*;
import java.util.*;

/**
 * @author Koushik Sen <ksen@cs.berkeley.edu>
 * @author Jacob Burnim <jburnim@cs.berkeley.edu>
 */
public class MaxPaths<G extends Generator & BoundedJoinSemilattice<G>>
    implements Serializable {

    private int length;
    private int numPaths;
    private ArrayList<Path> paths;
    private LinkedHashSet<G> maxGenerators;
    private HashMap<G, Integer> pathCounts;
    private HashMap<Integer, Integer> lengthCounts;
    private GeneratorFactory<G> generatorFactory;

    private static final int kMaxPathsToStore = 10;

    public MaxPaths(GeneratorFactory<G> generatorFactory) {
        this.length = -1;
        this.numPaths = 0;
        this.paths = new ArrayList<Path>();
        this.maxGenerators = new LinkedHashSet<G>();
        this.pathCounts = new HashMap<G, Integer>();
        this.lengthCounts = new HashMap<Integer, Integer>();
        this.generatorFactory = generatorFactory;
    }

    private ArrayList<String> getMap(String file) {
        ObjectInputStream in;
        ArrayList<String> ret;
        try {
            in = new ObjectInputStream(new BufferedInputStream(new FileInputStream(file)));
            ret = (ArrayList<String>) in.readObject();
            in.close();
            return ret;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    public synchronized void updateMaxHistory(History history) {
        numPaths++;

        // Update our count of paths-per-path-length.
        Integer count = lengthCounts.get(history.getBranchCount());
        if (count == null) {
            lengthCounts.put(history.getBranchCount(), 1);
        } else {
            lengthCounts.put(history.getBranchCount(), count + 1);
        }

        // If we are only doing random testing, no need to run the
        // rest of this method.  (This is kind of an ugly hack.)
        if (Globals.mode == Globals.PERF_RANDOM_MODE)
            return;

        // Update our count of paths-per-set-of-branches.
        G gen = generatorFactory.makeGenerator(history);
        count = pathCounts.get(gen);
        if (count == null) {
            pathCounts.put(gen, 1);
        } else {
            pathCounts.put(gen, count + 1);
        }

        // Update the list/set of longest paths and maximal generators.
        if (length < history.getBranchCount()) {
            paths.clear();
            maxGenerators.clear();
            length = history.getBranchCount();
        }
        if (length == history.getBranchCount()) {
            if (paths.size() < kMaxPathsToStore) {
                Path p = new Path();
                p.populateTrace(history);
                p.setBranchCount(history.getBranchCount());
                paths.add(p);
            }
            maxGenerators.add(gen);
        }
    }

    public synchronized void printStats() {
        System.out.println("Number of paths of each length:");

        long weightedSum = 0;
        TreeSet<Integer> lengthSet = new TreeSet<Integer>(lengthCounts.keySet());
        for (int length : lengthSet) {
            long count = lengthCounts.get(length);
            System.out.println(length + "\t" + count);
            weightedSum += length * count;
        }
        System.out.println("Average length: " + weightedSum / (double) numPaths);
        System.out.println();

        System.out.println("Number of paths: " + numPaths);
        System.out.println("Number of longest paths: " + paths.size());
        if (paths.size() > 0) {
            System.out.println("Length of longest paths: " + paths.get(0).getBranchCount());
        }
        System.out.println();
    }

    public synchronized int getNumMaximalGenerators() {
        return maxGenerators.size();
    }

    public G getMaximalGenerator(int i) {
        printStats();
        System.out.println("Number of unique generators: " + pathCounts.size());
        System.out.println("Number of unique maximal generators: "
                           + maxGenerators.size());

        for (G g : maxGenerators) {
            if (i-- == 0)
                return g;
        }
        throw new IndexOutOfBoundsException();
    }

    public synchronized G getBestMaximalGenerator() {
        // First find best maximal generator just looking executions
        // on the current input size.
        G bot = maxGenerators.iterator().next().getBottomElement();
        G best = getBestMaximalGenerator(bot, maxGenerators, pathCounts, true);

        if (!Globals.joinWithPrevGenerator)
            return best;

        System.out.println("\nGenerator before joining:");
        System.out.println(best.toString());

        // Now make sure that the generator is maximal for previous
        // (i.e., smaller) input sizes.
        ArrayList<Summary<G>> summaries = Summary.<G>readSummaries();
        for (int i = summaries.size()-1; i >= 0; i--) {
            best = getBestMaximalGenerator(best,
                                           summaries.get(i).getMaxGenerators(),
                                           summaries.get(i).getPathCounts(),
                                           false);
        }

        // Save a new summary.
        summaries.add(new Summary<G>(maxGenerators, pathCounts));
        Summary.<G>writeSummaries(summaries);

        // Done.
        return best;
    }

    public synchronized G getBestMaximalGenerator(G toJoin,
                                                  LinkedHashSet<G> max,
                                                  HashMap<G, Integer> count,
                                                  boolean verbose) {
        if (verbose) {
            printStats();
            System.out.println("Number of unique generators: " + count.size());
            System.out.println("Number of unique maximal generators: "
                               + max.size());
        }

        // For each generator G which generates longest paths, compute the
        // total number of paths it generates by summing pathCounts[H] over
        // all generators H with H <= G.  (Obviously this requires that
        // G generates a path p iff the H_p <= G, letting H_p be the generator
        // derived from p.)
        //
        // Remember the maximal generator which generates the fewest total paths.
        G ret = null;
        int minPaths = Integer.MAX_VALUE;
        for (G gen : max) {
            G joined = gen.join(toJoin);
            int paths = 0;
            for (Map.Entry<G, Integer> e : count.entrySet()) {
                if (e.getKey().isLessThanOrEqualTo(joined)) {
                    paths += e.getValue();
                }
            }
            if (verbose) {
                System.out.println("    Max-generator generates "
                                   + paths + " paths.");
            }
            if (paths < minPaths) {
                minPaths = paths;
                ret = joined;
            }
        }

        return ret;
    }

    public synchronized void printTrace(String file, History history) {
        ArrayList<String> map = getMap(Parameters.iidToLineMapFile);
        try {
            Path p = new Path();
            p.populateTrace(history);
            PrintStream out = new PrintStream(new BufferedOutputStream(new FileOutputStream(file)));
            out.println("<html><body>");
            out.println("<hr>(length=" + p.getBranchCount() + ")<hr>");
            p.printTrace(out, map);
            out.println("</body></html>");
            out.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            Runtime.getRuntime().halt(1);
        }
    }

    public synchronized void printTraces(String file) {
        ArrayList<String> map = getMap(Parameters.iidToLineMapFile);
        try {
            if (paths != null) {
                PrintStream out = new PrintStream(new BufferedOutputStream(new FileOutputStream(file)));
                out.println("<html><body>");
                int i = 0;
                for (Path path : paths) {
                    i++;
                    out.println("<hr>Path " + i + " (length=" + path.getBranchCount() + ")<hr>");
                    path.printTrace(out, map);
                }
                out.println("</body></html>");
                out.close();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            Runtime.getRuntime().halt(1);
        }
    }

}
