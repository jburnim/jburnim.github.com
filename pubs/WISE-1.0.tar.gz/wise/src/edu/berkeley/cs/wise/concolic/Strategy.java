/**
 * Copyright (c) 2011, Regents of the University of California
 * All rights reserved.
 * <p/>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * <p/>
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * <p/>
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 * <p/>
 * 3. Neither the name of the University of California, Berkeley nor
 * the names of its contributors may be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 * <p/>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package edu.berkeley.cs.wise.concolic;

import edu.berkeley.cs.wise.concolic.path.MaxPaths;
import edu.berkeley.cs.wise.concolic.generators.Generator;
import edu.berkeley.cs.wise.concolic.generators.BranchSetGenerator;
import edu.berkeley.cs.wise.concolic.generators.BranchPolicyGenerator;
import edu.berkeley.cs.wise.concolic.solvers.Solution;

import java.util.Set;
import java.util.Stack;

/**
 * @author Koushik Sen <ksen@cs.berkeley.edu>
 * @author Jacob Burnim <jburnim@cs.berkeley.edu>
 */
public class Strategy {
    private History history;
    private PathConstraint pathConstraint;
    private int solverCount;

    public Strategy(History history, PathConstraint pathConstraint) {
        this.history = history;
        this.pathConstraint = pathConstraint;
        this.solverCount = 0;
    }

    public int getSolverCount() {
        return solverCount;
    }

    public History solveFromBeginning() {
        if (pathConstraint.isEmpty()) {
            return null;
        }
        int inputSize = history.getNumInputs();
        if (!history.isPredictionFailed()) {
            //history.print();
            //pathConstraint.print();
            int sz = history.size();
            for (int i = 0; i < sz; i++) {
                BranchHistoryElement e = history.getBranchAt(i);
                if (e != null && !e.isDone() && e.getConstraintIndex() >= 0
                        && e.getConstraintIndex() + 5 <= pathConstraint.size()) {
                    History tmp = history.makeCopy();
                    if (solve(pathConstraint, tmp, e.getConstraintIndex(), inputSize)) {
                        tmp.flipBranchAndSetDoneAt(i);
                        tmp.setPriority(i);
                        history.setDoneAt(i);
                        return tmp;
                    }
                }
            }
            //System.out.println("************************** Search complete! **************************");
            return null;
        }
        return null;
    }

    private Solution solve(PathConstraint pc, int constraintIndex, int inputSize) {
        solverCount++;

        return SolverThread.solve(pc, constraintIndex, inputSize);
    }

    private boolean solve(PathConstraint pc, BranchHistoryElement e, int inputSize) {
        if (!e.hasSolution()) {
            if (e.getConstraintIndex() >= 0) {
                e.setSolution(solve(pathConstraint, e.getConstraintIndex(), inputSize));
            } else {
                e.setSolution(null);
            }
        }
        return (e.getSolution() != null);
    }

    private boolean solve(PathConstraint pc, History history, int constraintIndex, int inputSize) {
        Solution soln = solve(pc, constraintIndex, inputSize);
        if (soln == null) {
            return false;
        } else {
            history.setInputs(soln);
            return true;
        }
    }

    public void solveAllBranches() {
        if (pathConstraint.isEmpty() || history.isPredictionFailed()) {
            return;
        }

        int inputSize = history.getNumInputs();
        int sz = history.size();
        for (int i = 0; i < sz; i++) {
            BranchHistoryElement e = history.getBranchAt(i);
            if ((e != null) && !e.isDone() && !e.hasSolution()) {
                if (e.getConstraintIndex() >= 0) {
                    e.setSolution(solve(pathConstraint, e.getConstraintIndex(), inputSize));
                } else {
                    e.setSolution(null);
                }
            }
        }
    }

    public int solve() {
        if (pathConstraint.isEmpty()) {
            return 1;
        }
        int inputSize = history.getNumInputs();
        if (!history.isPredictionFailed()) {
            //history.print();
            //pathConstraint.print();
            int sz = history.size();
            for (int i = sz - 1; i >= 0; i--) {
                BranchHistoryElement e = history.getBranchAt(i);
                if (e != null && !e.isDone() && (e.getConstraintIndex() >= 0)) {
                    Solution soln = null;
                    if (e.hasSolution()) {
                        // If we've already solved to negate this branch, reuse the solution.
                        soln = e.getSolution();
                    } else {
                        // Otherwise, solve.
                        soln = solve(pathConstraint, e.getConstraintIndex(), inputSize);
                        e.setSolution(soln);
                    }
                    if (soln != null) {
                        Solution oldSoln = history.getInputs();
                        history.setInputs(soln);
                        history.flipBranchAndSetDoneAt(i);
                        e.setSolution(oldSoln);
                        return 0;
                    }
                }
            }
            System.out.println("************************** Search complete! **************************");
            return 1;
        }
        return 1;
    }

    public int solve(Generator generator, MaxPaths<?> max, int inputCounter) {
        if (generator instanceof BranchSetGenerator) {
            return solve(((BranchSetGenerator)generator).branchSet, max, inputCounter);

        } else if (generator instanceof BranchPolicyGenerator) {
            BranchPolicyGenerator twbsg = (BranchPolicyGenerator)generator;
            return solve(twbsg.allowedBranches, twbsg.partiallyAllowedBranches, max, inputCounter);

        } else {
            throw new UnsupportedOperationException("Cannot solve with generator: "
                                                    + generator.getClass());
        }
    }

    public int solve(Set<Branch> allowedBranches, Set<Branch> partiallyAllowedBranches,
                     MaxPaths<?> max, int inputCounter) {

        if (history.isPredictionFailed()) {
            return 1;
        }

        int inputSize = history.getNumInputs();
        int size = history.size();

        // Find the first forbidden branch.
        int forbidden = -1;
        for (int i = 0; i < size; i++) {
            BranchHistoryElement e = history.getBranchAt(i);
            if (e == null) continue;

            Branch b = new Branch(e.getIid(), e.getBranch());

            if (allowedBranches.contains(b))
                continue;

            if (!solve(pathConstraint, e, inputSize) && partiallyAllowedBranches.contains(b))
                continue;

            forbidden = i;
            break;
        }

        // Backtrack until we have eliminated the first forbidden branch.
        for (int i = forbidden; i >= 0; i--) {
            BranchHistoryElement e = history.getBranchAt(i);
            if ((e != null) && !e.isDone()
                    && allowedBranches.contains(new Branch(e.getIid(), !e.getBranch()))
                    && solve(pathConstraint, e, inputSize)) {
                Solution oldSoln = history.getInputs();
                history.setInputs(e.getSolution());
                history.flipBranchAndSetDoneAt(i);
                e.setSolution(oldSoln);
                return 0;
            }
        }
        if (forbidden >= 0) {
            // System.out.println("Cannot avoid forbidden branchSet -- search halted.");
            return 1;
        }

        // System.out.println("LEGAL PATH!!!");
        max.updateMaxHistory(history);

        // Depth-first search in the space of allowed branches.
        for (int i = size - 1; i >= 0; i--) {
            BranchHistoryElement e = history.getBranchAt(i);
            if ((e != null) && !e.isDone()
                    && allowedBranches.contains(new Branch(e.getIid(), !e.getBranch()))
                    && solve(pathConstraint, e, inputSize)) {
                Solution oldSoln = history.getInputs();
                history.setInputs(e.getSolution());
                history.flipBranchAndSetDoneAt(i);
                e.setSolution(oldSoln);
                return 0;
            }
        }

        // Done.
        return 1;
    }

    public int solve(Set<Branch> branchSet, MaxPaths<?> max, int inputCounter) {
        if (history.isPredictionFailed()) {
            return 1;
        }

        int inputSize = history.getNumInputs();
        int size = history.size();

        // Find the first forbidden branch.
        int forbidden = -1;
        for (int i = 0; i < size; i++) {
            BranchHistoryElement e = history.getBranchAt(i);
            if ((e != null) && !branchSet.contains(new Branch(e.getIid(), e.getBranch()))) {
                forbidden = i;
                break;
            }
        }

        // Backtrack until we have eliminated the first forbidden branch.
        for (int i = forbidden; i >= 0; i--) {
            BranchHistoryElement e = history.getBranchAt(i);
            if ((e != null) && !e.isDone() && (e.getConstraintIndex() >= 0)
                    && branchSet.contains(new Branch(e.getIid(), !e.getBranch()))
                    && solve(pathConstraint, history, e.getConstraintIndex(), inputSize)) {
                history.flipBranchAndSetDoneAt(i);
                return 0;
            }
        }
        if (forbidden >= 0) {
            // System.out.println("Cannot avoid forbidden branchSet -- search halted.");
            return 1;
        }

        // System.out.println("LEGAL PATH!!!");
        max.updateMaxHistory(history);

        // Depth-first search in the space of allowed branches.
        for (int i = size - 1; i >= 0; i--) {
            BranchHistoryElement e = history.getBranchAt(i);
            if ((e != null) && !e.isDone() && (e.getConstraintIndex() >= 0)
                    && branchSet.contains(new Branch(e.getIid(), !e.getBranch()))
                    && solve(pathConstraint, history, e.getConstraintIndex(), inputSize)) {
                history.flipBranchAndSetDoneAt(i);
                //history.print();
                return 0;
            }
        }

        // Done.
        return 1;
    }
}
