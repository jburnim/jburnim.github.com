/**
 * Copyright (c) 2011, Regents of the University of California
 * All rights reserved.
 * <p/>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * <p/>
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * <p/>
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 * <p/>
 * 3. Neither the name of the University of California, Berkeley nor
 * the names of its contributors may be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 * <p/>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package edu.berkeley.cs.wise.concolic;

import edu.berkeley.cs.wise.concolic.solvers.Solution;

import java.io.*;

/**
 * @author Koushik Sen <ksen@cs.berkeley.edu>
 * @author Jacob Burnim <jburnim@cs.berkeley.edu>
 */
public class SolverThread extends Thread {
    private InputStream is;
    private Solution solution;

    public static Solution solve(PathConstraint pc, int n, int nInputs) {
        try {
            // pc.sendIncrementalFormulaToYicesSolver(System.out, n, nInputs);
            Runtime rt = Runtime.getRuntime();
            Process proc = rt.exec(Globals.yicesCommand);
            SolverThread outputProcessor = new SolverThread(proc.getInputStream());
            PrintStream out = new PrintStream(new BufferedOutputStream(proc.getOutputStream()));
            outputProcessor.start();
            pc.sendFormulaToYicesSolver(out, n, nInputs);
            out.close();
            proc.waitFor();
            outputProcessor.join();
            proc.getOutputStream().close();
            proc.getInputStream().close();
            proc.getErrorStream().close();
            proc.destroy();
            return outputProcessor.solution;
        } catch (IOException ioe) {
            ioe.printStackTrace();
            Runtime.getRuntime().halt(1);
            return null;
        } catch (InterruptedException ie) {
            ie.printStackTrace();
            Runtime.getRuntime().halt(1);
            return null;
        }
    }


    public SolverThread(InputStream is) {
        this.is = is;
        this.solution = null;
    }

    public void run() {
        try {
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);
            String line = null;

            line = br.readLine();
            //System.out.println(line);
            if (!line.startsWith("sat")) {
                if (!line.startsWith("unsat")) {
                    System.err.println("Call to Yices failed (concolic.yices = "
                                       + Globals.yicesCommand + ")");
                    Runtime.getRuntime().halt(1);
                }
                return;
            }

            Solution soln = new Solution();
            while ((line = br.readLine()) != null) {
                //System.out.println(line);
                if (line.startsWith("(")) {
                    String[] tokens = line.split(" ");
                    int xi = Integer.parseInt(tokens[1].substring(1));
                    String tmp = tokens[2].trim();
                    long val = Long.parseLong(tmp.substring(0, tmp.length() - 1));
                    soln.setVar(xi, val);
                }
            }

            this.solution = soln;

        } catch (IOException ioe) {
            ioe.printStackTrace();
            Runtime.getRuntime().halt(1);
        }
    }
}

