/**
 * Copyright (c) 2011, Regents of the University of California
 * All rights reserved.
 * <p/>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * <p/>
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * <p/>
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 * <p/>
 * 3. Neither the name of the University of California, Berkeley nor
 * the names of its contributors may be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 * <p/>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package edu.berkeley.cs.wise.concolic;

import java.io.PrintStream;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

/**
 * @author Koushik Sen <ksen@cs.berkeley.edu>
 * @author Jacob Burnim <jburnim@cs.berkeley.edu>
 */
public class LinearExpression implements Expression {
    private TreeMap<Integer, Long> linear;
    private long constant;
    private String op;  // in case the linear expression is a constraint

    public boolean equals(Object o) {
        if (this == o)
            return true;
        if ((o == null) || (getClass() != o.getClass()))
            return false;
        LinearExpression e = (LinearExpression) o;
        return (linear.equals(e.linear)
                && (constant == e.constant)
                && (((op != null) && op.equals(e.op))
                    || ((op == null) && (e.op == null))));
    }

    public int hashCode() {
        int ret = 37;
        ret = 71 * ret + linear.hashCode();
        ret = 71 * ret + (int) constant;
        if (op != null)
            ret = 71 * ret + op.hashCode();
        return ret;
    }

    public LinearExpression(int i) {
        linear = new TreeMap<Integer, Long>();
        linear.put(i, 1L);
        constant = 0;
        op = null;
    }


    public LinearExpression() {
        linear = new TreeMap<Integer, Long>();
        constant = 0;
        op = null;
    }

    public LinearExpression(LinearExpression e) {
        this.linear = new TreeMap<Integer, Long>(e.linear);
        constant = e.constant;
        op = e.op;
    }

    public Expression negate() {
        LinearExpression tmp = new LinearExpression();
        for (Integer integer : linear.keySet()) {
            tmp.linear.put(integer, -linear.get(integer));
        }
        tmp.constant = -constant;
        return tmp;
    }

    public Expression add(long l) {
        return add(l, true);
    }

    private Expression add(long l, boolean add) {
        LinearExpression tmp = new LinearExpression(this);
        if (add)
            tmp.constant = constant + l;
        else
            tmp.constant = constant - l;
        return tmp;
    }

    public Expression add(Expression l) {
        return add(l, true);
    }

    private Expression add(Expression l, boolean add) {
        LinearExpression tmp = new LinearExpression(this);
        LinearExpression e = (LinearExpression) l;
        for (Integer integer : e.linear.keySet()) {
            Long coeff = linear.get(integer);
            if (coeff != null) {
                long toadd;
                if (add) {
                    toadd = coeff + e.linear.get(integer);
                } else {
                    toadd = coeff - e.linear.get(integer);
                }
                if (toadd == 0) {
                    tmp.linear.remove(integer);
                } else {
                    tmp.linear.put(integer, toadd);
                }
            } else {
                if (add) {
                    coeff = e.linear.get(integer);
                } else {
                    coeff = -e.linear.get(integer);
                }
                tmp.linear.put(integer, coeff);
            }
        }
        if (tmp.linear.isEmpty()) {
            return null;
        }

        if (add)
            tmp.constant = this.constant + e.constant;
        else
            tmp.constant = this.constant - e.constant;

        return tmp;
    }

    public Expression subtractFrom(long l) {
        LinearExpression e = (LinearExpression) negate();
        e.constant = l + e.constant;
        return e;
    }

    public Expression subtract(long l) {
        return add(l, false);
    }

    public Expression subtract(Expression l) {
        return add(l, false);
    }

    public Expression multiply(long l) {
        if (l == 0) return null;
        if (l == 1) return this;
        LinearExpression tmp = new LinearExpression();
        for (Iterator<Integer> iterator = linear.keySet().iterator(); iterator.hasNext();) {
            Integer integer = iterator.next();
            tmp.linear.put(integer, l * linear.get(integer));
        }
        tmp.constant = l * constant;
        return tmp;
    }

    public void setop(String op) {
        if (op.equals("!=")) this.op = "/=";
        else if (op.equals("==")) this.op = "=";
        else this.op = op;
    }

    public void not() {
        if (op.equals(">")) op = "<=";
        else if (op.equals("<")) op = ">=";
        else if (op.equals("<=")) op = ">";
        else if (op.equals(">=")) op = "<";
        else if (op.equals("=")) op = "/=";
        else if (op.equals("/=")) op = "=";
    }

    public Set<Integer> getSymbols() {
        return linear.keySet();
    }


    public String toString() {
        StringBuilder sb = new StringBuilder();
        boolean first = true;
        for (Integer integer : linear.keySet()) {
            Long l = linear.get(integer);
            if (first) {
                first = false;
            } else {
                sb.append('+');
            }
            if (l < 0) {
                sb.append('(');
                sb.append(l);
                sb.append(")*x");
                sb.append(integer);
            } else if (l == 1) {
                sb.append("x");
                sb.append(integer);
            } else if (l > 0) {
                sb.append(l);
                sb.append("*x");
                sb.append(integer);
            }
        }
        if (constant != 0) {
            if (constant > 0)
                sb.append('+');
            sb.append(constant);
        }
        if (op != null) {
            sb.append(op);
            sb.append('0');
        }
        return sb.toString();
    }

    public void print(PrintStream out) {
        out.print("(");
        out.print(op);
        out.print(" (+ ");
        for (Integer key : linear.keySet()) {
            Long val = linear.get(key);
            if (val < 0) {
                out.print("(* (- 0 ");
                out.print(val.toString().substring(1));
                out.print(") x");
            } else {
                out.print("(* ");
                out.print(val);
                out.print(" x");
            }
            out.print(key);
            out.print(") ");
        }
        if (constant < 0) {
            out.print("(- 0 ");
            out.print(Long.toString(constant).substring(1));
            out.print(")");
        } else if (constant > 0) {
            out.print(constant);
        }
        out.print(") 0)");
    }

    public double[] getCoeffs() {
        double[] ret = new double[linear.size()];
        int i = 0;
        for (long v : linear.values()) {
            ret[i++] = v;
        }
        return ret;
    }

    public int[] getVars() {
        int[] ret = new int[linear.size()];
        int i = 0;
        for (int k : linear.keySet()) {
            ret[i++] = k + 1;
        }
        return ret;
    }

    public String getOp() {
        return op;
    }

    public int getSize() {
        return linear.size();
    }

    public double getConstant() {
        return (double) constant;
    }

    public Collection<Integer> getInputs() {
        return Collections.unmodifiableSet(linear.keySet());
    }
}
