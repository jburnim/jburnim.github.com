/**
 * Copyright (c) 2011, Regents of the University of California
 * All rights reserved.
 * <p/>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * <p/>
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * <p/>
 * 2. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 * <p/>
 * 3. Neither the name of the University of California, Berkeley nor
 * the names of its contributors may be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 * <p/>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package edu.berkeley.cs.wise.concolic.generators;

import java.util.Collections;
import java.util.Set;
import java.util.TreeSet;
import edu.berkeley.cs.wise.concolic.Branch;
import edu.berkeley.cs.wise.concolic.BranchHistoryElement;
import edu.berkeley.cs.wise.concolic.History;

/**
 * @author Jacob Burnim <jburnim@cs.berkeley.edu>
 */
public class BranchPolicyGenerator
    implements Generator, BoundedJoinSemilattice<BranchPolicyGenerator> {

    public static class Factory implements GeneratorFactory<BranchPolicyGenerator> {
        public BranchPolicyGenerator makeGenerator(History hist) {
            return new BranchPolicyGenerator(hist);
        }
    }

    private static final BranchPolicyGenerator bottom =
        new BranchPolicyGenerator(Collections.<Branch>emptySet(),
                                  Collections.<Branch>emptySet());

    // TODO(jburnim): Figure out the right interface for having
    // generators guide concolic search.
    final public Set<Branch> allowedBranches;
    final public Set<Branch> partiallyAllowedBranches;

    BranchPolicyGenerator(Set<Branch> ab, Set<Branch> pab) {
        allowedBranches = ab;
        partiallyAllowedBranches = pab;
    }

    BranchPolicyGenerator(History hist) {
        allowedBranches = new TreeSet<Branch>();
        partiallyAllowedBranches = new TreeSet<Branch>();
        for (int i = 0; i < hist.size(); i++) {
            BranchHistoryElement e = hist.getBranchAt(i);
            if (e != null) {
                if (!e.hasSolution()) {
                    System.out.println("BranchPolicyGenerator: !e.hasSolution()");
                    System.exit(1);
                }
                if (e.getSolution() != null) {
                    allowedBranches.add(new Branch(e.getIid(), e.getBranch()));
                } else {
                    partiallyAllowedBranches.add(new Branch(e.getIid(), e.getBranch()));
                }
            }
        }
        partiallyAllowedBranches.removeAll(allowedBranches);
    }

    public String toString() {
        TreeSet<Branch> tmp = new TreeSet<Branch>(partiallyAllowedBranches);
        tmp.addAll(allowedBranches);
        String ret = "";
        for (Branch b : tmp) {
            ret = ret + b + (allowedBranches.contains(b) ? " " : "* " );
        }
        return ret;
    }

    public boolean isLessThan(BranchPolicyGenerator g) {
        return (this.isLessThanOrEqualTo(g) && !this.equals(g));
    }

    public boolean isLessThanOrEqualTo(BranchPolicyGenerator g) {
        if (!g.allowedBranches.containsAll(this.allowedBranches))
            return false;
        for (Branch b : this.partiallyAllowedBranches) {
            if (!g.allowedBranches.contains(b)
                && !g.partiallyAllowedBranches.contains(b)) {
                return false;
            }
        }
        return true;
    }

    public BranchPolicyGenerator join(BranchPolicyGenerator g) {
        if (g.isLessThanOrEqualTo(this)) {
            return this;
        } else if (this.isLessThanOrEqualTo(g)) {
            return g;
        }

        Set<Branch> ab = new TreeSet<Branch>(allowedBranches);
        ab.addAll(g.allowedBranches);

        Set<Branch> pab = new TreeSet<Branch>(partiallyAllowedBranches);
        pab.addAll(g.partiallyAllowedBranches);

        pab.removeAll(ab);
        return new BranchPolicyGenerator(ab, pab);
    }

    public BranchPolicyGenerator getBottomElement() {
        return bottom;
    }

    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null)
            return false;
        if (this.getClass() != o.getClass())
            return false;

        BranchPolicyGenerator g = (BranchPolicyGenerator)o;
        return (this.allowedBranches.equals(g.allowedBranches)
                && this.partiallyAllowedBranches.equals(g.partiallyAllowedBranches));
    }

    public int hashCode() {
        return (101*this.allowedBranches.hashCode()
                + this.partiallyAllowedBranches.hashCode());
    }
}
