/*
 * Copyright (c) 2009, Regents of the University of California
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the
 * distribution.
 *
 * Neither the name of the University of California, Berkeley nor the
 * names of its contributors may be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <pthread.h>
#include <stdio.h>

#define NUM_THREADS 2

#include "bakery.c"

void * thread0_f(void * arg) {
  load_load_fence();

  int i;
  for (i = 0; i < 3; i++) {
    bake_lock(0);

    printf("thread 0 entering critical section\n");

    printf("thread 0 exiting critical section\n");

    bake_unlock(0);
  }

  store_store_fence();
  return NULL;
}

void * thread1_f(void * arg) {
  load_load_fence();

  int i;
  for (i = 0; i < 3; i++) {
    bake_lock(1);

    printf("thread 1 entering critical section\n");

    printf("thread 1 exiting critical section\n");

    bake_unlock(1);
  }

  store_store_fence();
  return NULL;
}

pthread_t thread0, thread1;

int main() {
  store_store_fence();
  pthread_create(&thread0, NULL, thread0_f, NULL);
  pthread_create(&thread1, NULL, thread1_f, NULL);
  pthread_join(thread0, NULL);
  pthread_join(thread1, NULL);
  load_load_fence();

  return 0;
}
