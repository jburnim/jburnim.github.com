/*
 * Copyright (c) 2007
 *   Sebastian Burckhardt <sburckha@cis.upenn.edu>
 *   Rajeev Alur          <alur@cis.upenn.edu>
 *   Milo Martin          <milom@cis.upenn.edu>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the
 * distribution.
 *
 * Neither the name of the University of California, Berkeley nor the
 * names of its contributors may be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "lsl_protos_c.h"

/* ---- data types  ---- */

typedef int value_t;

typedef struct node {
    struct node *next;
    value_t value;
} node_t;

typedef struct queue {
    node_t *head;
    node_t *tail;
} queue_t;

/* ---- operations  ---- */

void init_queue(queue_t *queue)
{
    node_t *node = lsl_malloc_noreuse(sizeof(node_t));
    node->next = 0;
    queue->head = queue->tail = node;
}

void enqueue(queue_t *queue, value_t value)
{
    node_t *node;
    node_t *tail;
    node_t *next;

    node = lsl_malloc_noreuse(sizeof(node_t));
    node->value = value;
    node->next = 0;
    while (TRUE) {
        tail = queue->tail;
        next = tail->next;
        if (tail == queue->tail)
            if (next == 0) {
                if (lsl_cas_ptr1(&tail->next, next, node)) {
                    break;
                }
            } else
                lsl_cas_ptr2(&queue->tail, tail, next);
    }
    lsl_cas_ptr3(&queue->tail, tail, node);
}

boolean_t dequeue(queue_t *queue, value_t *pvalue)
{
    node_t *head;
    node_t *tail;
    node_t *next;

    while (TRUE) {
        head = queue->head;
        tail = queue->tail;
        next = head->next;
        if (head == queue->head) {
            if (head == tail) {
                if (next == 0)
                    return FALSE;
                lsl_cas_ptr4(&queue->tail, tail, next);
            } else {
                *pvalue = next->value;
                if (lsl_cas_ptr5(&queue->head, head, next))
                    break;
            }
        }
    }
    lsl_free_noreuse(head);
    return TRUE;
}
