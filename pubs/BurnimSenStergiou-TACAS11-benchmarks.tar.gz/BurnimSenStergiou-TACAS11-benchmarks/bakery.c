/*
 * This code is from the Wikipedia article "Lamport's bakery algorithm"
 * (http://en.wikipedia.org/wiki/Lamport's_bakery_algorithm).  The work
 * is copyrighted by the Wikipedia editors and contributors.  The
 * original work has been modified.
 *
 * This work is licensed under the Creative Commons
 * Attribution-ShareAlike 3.0 Unported License. To view a copy of this
 * license, visit http://creativecommons.org/licenses/by-sa/3.0/ .
 */

int entering[NUM_THREADS];
int number[NUM_THREADS];

int max_number() {
  int i;
  int max = 0;

  for (i = 0; i < NUM_THREADS; i++) {
    if (number[i] > max)
      max = number[i];
  }

  return max;
}

void bake_lock(int i) {
  int j;

  entering[i] = 1;
  number[i] = 1 + max_number();
  entering[i] = 0;
  for (j = 0; j < NUM_THREADS; j++) {
    while (entering[j]) { }

    while ((number[j] != 0)
           && ((number[j] < number[i]) ||
               ((number[i] == number[j]) && (j < i))))  { }
  }
}

void bake_unlock(int i) {
  number[i] = 0;
}
