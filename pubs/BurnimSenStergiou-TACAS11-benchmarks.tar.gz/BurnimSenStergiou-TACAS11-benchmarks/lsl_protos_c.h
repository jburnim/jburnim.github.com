#ifndef LSL_PROTOS_H
#define LSL_PROTOS_H

#include <pthread.h>
#include <stddef.h>

/* general */
enum boolean {FALSE = 0, TRUE = 1};
typedef enum boolean boolean_t;

/* unsigned types */
typedef unsigned uint32;
typedef unsigned long long uint64;

/* fences */
extern void store_load_fence();
extern void store_store_fence();
extern void load_load_fence();

/* dynamic memory allocation */
extern void* lsl_malloc(size_t size);
extern void lsl_free(void* ptr);

/* dynamic memory allocation without pointer reuse */
extern void* lsl_malloc_noreuse(size_t size);
extern void lsl_free_noreuse(void* ptr);

/* verification directives */
extern void lsl_assert(boolean_t expr);
extern void lsl_assume(boolean_t expr);

/* simple lock */
typedef pthread_mutex_t lsl_lock_t;
extern void lsl_initlock(lsl_lock_t* lock);
extern void lsl_lock(lsl_lock_t* lock);
extern void lsl_unlock(lsl_lock_t* lock);
extern boolean_t lsl_trylock(lsl_lock_t* lock);

/* compare-and-swap */
extern boolean_t lsl_cas_ptr1(void* loc, void* old, void* new_);
extern boolean_t lsl_cas_ptr2(void* loc, void* old, void* new_);
extern boolean_t lsl_cas_ptr3(void* loc, void* old, void* new_);
extern boolean_t lsl_cas_ptr4(void* loc, void* old, void* new_);

/* double compare-and-swap */
extern boolean_t lsl_dcas_ptr1(void* loc1, void* loc2, void* old1, void* old2, void* new1, void* new2);
extern boolean_t lsl_dcas_ptr2(void* loc1, void* loc2, void* old1, void* old2, void* new1, void* new2);
extern boolean_t lsl_dcas_ptr3(void* loc1, void* loc2, void* old1, void* old2, void* new1, void* new2);
extern boolean_t lsl_dcas_ptr4(void* loc1, void* loc2, void* old1, void* old2, void* new1, void* new2);
extern boolean_t lsl_dcas_ptr5(void* loc1, void* loc2, void* old1, void* old2, void* new1, void* new2);
extern boolean_t lsl_dcas_ptr6(void* loc1, void* loc2, void* old1, void* old2, void* new1, void* new2);

#endif /* LSL_PROTOS_H */
