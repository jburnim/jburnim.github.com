/*
 * Copyright (c) 2007
 *   Sebastian Burckhardt <sburckha@cis.upenn.edu>
 *   Rajeev Alur          <alur@cis.upenn.edu>
 *   Milo Martin          <milom@cis.upenn.edu>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the
 * distribution.
 *
 * Neither the name of the University of California, Berkeley nor the
 * names of its contributors may be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "lsl_protos_c.h"

/* ---- data types ---- */

#define sentinel_min_value -10
#define min_value          2
#define max_value          3
#define sentinel_max_value 10


/* data values */
typedef int value_t;

typedef struct node {
  struct node *next;
  value_t key;
  lsl_lock_t lock;
  boolean_t marked;
} node_t;

typedef struct list {
  node_t *head;
  node_t *tail;
} list_t;

/* ---- operations for list ---- */

void init_list(list_t *list)
{
  node_t *node;
  node = lsl_malloc_noreuse(sizeof(node_t));
  node->next = 0;
  node->key = sentinel_max_value;
  node->marked = FALSE; /* trace1 */
  lsl_initlock(&node->lock);
  list->tail = node;
  node = lsl_malloc_noreuse(sizeof(node_t));
  node->next = list->tail;
  node->key = sentinel_min_value;
  node->marked = FALSE; /* trace1 */
  lsl_initlock(&node->lock);
  list->head = node;
}

boolean_t contains(list_t *list, value_t key, boolean_t allow_retries) {
  node_t *curr;

  curr = list->head;
  while(curr->key < key) {
    curr = curr->next;
  }
  if (curr->key == key && !curr->marked)
    return TRUE;
  else
    return FALSE;
}

void locate(list_t *list, value_t key, node_t **left, node_t **right, boolean_t allow_retries) {
  node_t *pred;
  node_t *curr;

  while (1) {
    pred = list->head;
    curr = pred->next;
    while(curr->key < key) {
      pred = curr;
      curr = curr->next;
    }
    lsl_lock(&pred->lock);
    lsl_lock(&curr->lock);
    if ( ! pred->marked
         && (! curr->marked)
         && (pred->next == curr)) {
      *left = pred;
      *right = curr;
      return;
    }
    lsl_assume(allow_retries);
    lsl_unlock(&pred->lock);
    lsl_unlock(&curr->lock);
  }
}

boolean_t add(list_t *list, value_t key, boolean_t allow_retries) {
  node_t *pred;
  node_t *curr;
  node_t *entry;
  boolean_t res;

  locate(list, key, &pred, &curr, allow_retries);
  if (curr->key != key) {
    entry = lsl_malloc_noreuse(sizeof(node_t));
    entry->key = key;
    entry->next = curr;
    entry->marked = FALSE; /* trace1 */
    lsl_initlock(&entry->lock); /* trace4 */
    pred->next = entry;
    res = TRUE;
  } else
    res = FALSE;
  lsl_unlock(&pred->lock);
  lsl_unlock(&curr->lock);
  return res;
}

boolean_t remov(list_t *list, value_t key, boolean_t allow_retries) {
  node_t *pred;
  node_t *curr;
  node_t *entry;
  boolean_t res;

  locate(list, key, &pred, &curr, allow_retries);
  if (curr->key == key) {
    curr->marked = TRUE;
    entry = curr->next;
    pred->next = entry;
    res = TRUE;
  } else
    res = FALSE;
  lsl_unlock(&pred->lock);
  lsl_unlock(&curr->lock);
  return res;
}
