
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

#define DEBUG 0

typedef pthread_mutex_t lsl_lock_t;

enum boolean {FALSE = 0, TRUE = 1};
typedef enum boolean boolean_t;

pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

extern "C" void store_load_fence() { }
extern "C" void store_store_fence() { }
extern "C" void load_load_fence() { }

extern "C" void* lsl_malloc(size_t size) {
  void* res = malloc(size);
  if (res == NULL) {
    fprintf(stderr,"lsl_malloc returned NULL");
    exit(1);
  }
  return res;
}

extern "C" void* lsl_malloc_noreuse(size_t size) {
  void* res = malloc(size);
  if (res == NULL) {
    fprintf(stderr,"lsl_malloc_noreuse returned NULL");
    exit(1);
  }
  return res;
}

/*
 * For small benchmarks, it is fine to not free memory.  This ensures
 * that lsl_malloc_noreuse will return memory not previously allocated
 * and freed.
 */
extern "C" void lsl_free_noreuse(void* ptr) { }
extern "C" void lsl_free(void* ptr) { }

extern "C" void lsl_assume(boolean_t expr) { }

extern "C" void lsl_initlock(lsl_lock_t* lock) {
  pthread_mutex_init(lock, NULL);
}

extern "C" void lsl_lock(lsl_lock_t* lock) {
  pthread_mutex_lock(lock);
  load_load_fence();
}

extern "C" void lsl_unlock(lsl_lock_t* lock) {
  store_store_fence();
  pthread_mutex_unlock(lock);
}

extern "C" int CAS(int iid, void** addr, void* old, void* new_) {
  pthread_mutex_lock(&lock);
  bool success = false;
  if (*addr == old) {
    *addr = new_;
    success = true;
  }
  pthread_mutex_unlock(&lock);
  return success;
}

extern "C" int lsl_cas_ptr1(void* loc, void* o, void* n) {
  return CAS(1002, (void**)loc, (void*)o, (void*)n);
}

extern "C" int lsl_cas_ptr2(void* loc, void* o, void* n) {
  return CAS(1003, (void**)loc, (void*)o, (void*)n);
}

extern "C" int lsl_cas_ptr3(void* loc, void* o, void* n) {
  return CAS(1004, (void**)loc, (void*)o, (void*)n);
}

extern "C" int lsl_cas_ptr4(void* loc, void* o, void* n) {
  return CAS(1005, (void**)loc, (void*)o, (void*)n);
}

extern "C" int lsl_cas_ptr5(void* loc, void* o, void* n) {
  return CAS(1013, (void**)loc, (void*)o, (void*)n);
}


extern "C" int DCAS(int iid, void** addr1, void** addr2,
                    void* old1, void* old2, void* new1, void* new2) {
  pthread_mutex_lock(&lock);
  bool success = false;
  if (*addr1 == old1 && *addr2 == old2) {
    *addr1 = new1;
    *addr2 = new2;
    success = true;
  }
  pthread_mutex_unlock(&lock);
  return success;
}


extern "C" int lsl_dcas_ptr1(void* loc1, void* loc2,
                             void* o1, void* o2, void* n1, void* n2) {
  return DCAS(1007,
              (void**)loc1, (void**)loc2,
              (void*)o1, (void*)o2, (void*)n1, (void*)n2);
}

extern "C" int lsl_dcas_ptr2(void* loc1, void* loc2,
                             void* o1, void* o2, void* n1, void* n2) {
  return DCAS(1008,
              (void**)loc1, (void**)loc2,
              (void*)o1, (void*)o2, (void*)n1, (void*)n2);
}

extern "C" int lsl_dcas_ptr3(void* loc1, void* loc2,
                             void* o1, void* o2, void* n1, void* n2) {
  return DCAS(1009,
              (void**)loc1, (void**)loc2,
              (void*)o1, (void*)o2, (void*)n1, (void*)n2);
}

extern "C" int lsl_dcas_ptr4(void* loc1, void* loc2,
                             void* o1, void* o2, void* n1, void* n2) {
  return DCAS(1010,
              (void**)loc1, (void**)loc2,
              (void*)o1, (void*)o2, (void*)n1, (void*)n2);
}

extern "C" int lsl_dcas_ptr5(void* loc1, void* loc2,
                             void* o1, void* o2, void* n1, void* n2) {
  return DCAS(1011,
              (void**)loc1, (void**)loc2,
              (void*)o1, (void*)o2, (void*)n1, (void*)n2);
}

extern "C" int lsl_dcas_ptr6(void* loc1, void* loc2,
                             void* o1, void* o2, void* n1, void* n2) {
  return DCAS(1012,
              (void**)loc1, (void**)loc2,
              (void*)o1, (void*)o2, (void*)n1, (void*)n2);
}
