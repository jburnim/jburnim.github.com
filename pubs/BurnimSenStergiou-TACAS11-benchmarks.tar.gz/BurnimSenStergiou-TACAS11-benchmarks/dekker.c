/*
 * This code is from the Wikipedia article "Dekker's algorithm"
 * (http://en.wikipedia.org/wiki/Dekker's_algorithm).  The work is
 * copyrighted by the Wikipedia editors and contributors.  The
 * original work has been modified.
 *
 * This work is licensed under the Creative Commons
 * Attribution-ShareAlike 3.0 Unported License. To view a copy of this
 * license, visit http://creativecommons.org/licenses/by-sa/3.0/ .
 */

int flag0 = 0;
int flag1 = 0;
int turn = 0;

void enter0() {
  flag0 = 1;
  while (flag1) {
    if (turn != 0) {
      flag0 = 0;
      while (turn != 0) { }
      flag0 = 1;
    }
  }
}

void exit0() {
  turn = 1;
  flag0 = 0;
}

void enter1() {
  flag1 = 1;
  while (flag0) {
    if (turn != 1) {
      flag1 = 0;
      while (turn != 1) { }
      flag1 = 1;
    }
  }
}

void exit1() {
  turn = 0;
  flag1 = 0;
}
