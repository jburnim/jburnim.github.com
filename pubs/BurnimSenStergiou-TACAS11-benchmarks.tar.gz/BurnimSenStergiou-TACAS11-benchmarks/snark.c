/*
 * Copyright (c) 2007
 *   Sebastian Burckhardt <sburckha@cis.upenn.edu>
 *   Rajeev Alur          <alur@cis.upenn.edu>
 *   Milo Martin          <milom@cis.upenn.edu>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the
 * distribution.
 *
 * Neither the name of the University of California, Berkeley nor the
 * names of its contributors may be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "lsl_protos_c.h"

/* data values */
typedef int value_t; // positive number (-1 reserved for special value)
#define CLAIMED -1

/* node objects */
typedef struct node {
  struct node *R;
  struct node *L;
  value_t V;
} node_t;

/* deque objects */
typedef struct deque {
  node_t *Dummy;
  node_t *LeftHat;
  node_t *RightHat;
} deque_t;

/* ---- operations for deque ---- */

void init_deque(deque_t *deque)
{
  node_t *dummy = lsl_malloc_noreuse(sizeof(node_t));
  dummy->L = dummy->R = dummy;
  deque->Dummy = dummy;
  deque->LeftHat = dummy;
  deque->RightHat = dummy;
}

void push_right(deque_t *deque, value_t value, boolean_t allow_retries)
{
  node_t *nd, *rh, *rhR, *lh;

  nd = lsl_malloc_noreuse(sizeof(node_t));
  nd->R = deque->Dummy;
  nd->V = value;
  while (TRUE) {
    rh = deque->RightHat;
    rhR = rh->R;
    if (rhR == rh) {
      nd->L = deque->Dummy;
      lh = deque->LeftHat;
      if (lsl_dcas_ptr1(&(deque->RightHat), &(deque->LeftHat), rh, lh, nd, nd)) /* A */
        return;
    } else {
      nd->L = rh;
      if (lsl_dcas_ptr2(&(deque->RightHat), &(rh->R), rh, rhR, nd, nd)) /* B */
        return;
    }
    lsl_assume(allow_retries);
  }
}

void push_left(deque_t *deque, value_t value, boolean_t allow_retries)
{
  node_t *nd, *lh, *lhL, *rh;

  nd = lsl_malloc_noreuse(sizeof(node_t));
  nd->L = deque->Dummy;
  nd->V = value;
  while (TRUE) {
    lh = deque->LeftHat;
    lhL = lh->L;
    if (lhL == lh) {
      nd->R = deque->Dummy;
      rh = deque->RightHat;
      if (lsl_dcas_ptr3(&(deque->LeftHat), &(deque->RightHat), lh, rh, nd, nd)) /* A' */
        return;
    } else {
      nd->R = lh;
      if (lsl_dcas_ptr4(&(deque->LeftHat), &(lh->L), lh, lhL, nd, nd)) /* B' */
        return;
    }
    lsl_assume(allow_retries);
  }
}

boolean_t pop_right(deque_t *deque, value_t *value, boolean_t allow_retries) {
  node_t *rh, *rhL;
  value_t result;
  while(TRUE) {
    rh = deque->RightHat;
    rhL = rh->L;
    if (rh->R == rh) {
      if (deque->RightHat == rh)
        return FALSE;
    } else {
      if (lsl_dcas_ptr5(&(deque->RightHat), &(rh->L), rh, rhL, rhL, rh)) {  /* D */
        result = rh->V;
        if (result != CLAIMED) {
          if (lsl_cas_ptr1(&(rh->V), result, CLAIMED)) {
            rh->R = deque->Dummy;
            *value = result;
            return TRUE;
          } else
            return FALSE;
        } else
          return FALSE;
      }
    }
    lsl_assume(allow_retries);
  }
}

boolean_t pop_left(deque_t *deque, value_t *value, boolean_t allow_retries) {
  node_t *lh, *lhR;
  value_t result;
  while(TRUE) {
    lh = deque->LeftHat;
    lhR = lh->R;
    if (lh->L == lh) {
      if (deque->LeftHat == lh)
        return FALSE;
    } else {
      if (lsl_dcas_ptr6(&(deque->LeftHat), &(lh->R), lh, lhR, lhR, lh)) {  /* D */
        result = lh->V;
        if (result != CLAIMED) {
          if (lsl_cas_ptr2(&(lh->V), result, CLAIMED)) {
            lh->L = deque->Dummy;
            *value = result;
            return TRUE;
          } else
            return FALSE;
        } else
          return FALSE;
      }
    }
    lsl_assume(allow_retries);
  }
}


