/*
 * Copyright (c) 2007
 *   Sebastian Burckhardt <sburckha@cis.upenn.edu>
 *   Rajeev Alur          <alur@cis.upenn.edu>
 *   Milo Martin          <milom@cis.upenn.edu>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the
 * distribution.
 *
 * Neither the name of the University of California, Berkeley nor the
 * names of its contributors may be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "lsl_protos_c.h"

/* ---- data types ---- */

#define sentinel_min_value -10
#define min_value          2
#define max_value          3
#define sentinel_max_value 10


/* data values */
typedef int value_t;

/* marked pointers */
typedef void *mpointer_t;

typedef struct node {
  mpointer_t next;
  value_t key;
} node_t;

typedef struct list {
  mpointer_t head;
  mpointer_t tail;
} list_t;


/* ---- constructor & accessors for marked pointers---- */

inline mpointer_t lsl_make_mpointer(node_t *ptr, boolean_t marked) {
  return (void*) (((ptrdiff_t) ptr) | marked);
}
inline node_t *lsl_get_mpointer_ptr(mpointer_t mpointer) {
  return (node_t *) ((((ptrdiff_t) mpointer) >> 1) << 1);
}
inline boolean_t lsl_get_mpointer_marked(mpointer_t mpointer) {
  return ((ptrdiff_t) mpointer) & 0x1;
}
inline mpointer_t lsl_set_mpointer_ptr(mpointer_t mpointer, node_t *ptr) {
  return (void*) (((ptrdiff_t) ptr) | (((ptrdiff_t) mpointer) & 0x1));
}
inline mpointer_t lsl_set_mpointer_marked(mpointer_t mpointer, boolean_t marked) {
  return (void*) ((((ptrdiff_t) mpointer >> 1) << 1) | marked);
}


/* ---- operations  ---- */

void init_list(list_t *list)
{
  node_t *node;

  node = lsl_malloc_noreuse(sizeof(node_t));
  node->next = lsl_make_mpointer(0, FALSE);
  node->key = sentinel_max_value;
  list->tail = lsl_make_mpointer(node, FALSE);
  node = lsl_malloc_noreuse(sizeof(node_t));
  node->next = list->tail;
  node->key = sentinel_min_value;
  list->head = lsl_make_mpointer(node, FALSE);
}

mpointer_t search(list_t *list, value_t search_key, mpointer_t *l_node, boolean_t allow_retries)
{
  mpointer_t l_node_next, r_node, t, t_next;

  do {
    t = list->head;
    t_next = lsl_get_mpointer_ptr(list->head)->next;

    /* 1 : find l_node and r_node */
    do {
      if (! lsl_get_mpointer_marked(t_next)) {
        *l_node = t;
        l_node_next = t_next;
      }
      t = lsl_set_mpointer_marked(t_next, FALSE);
      if (t == list->tail)
        break;
      t_next = lsl_get_mpointer_ptr(t)->next;
    } while ( lsl_get_mpointer_marked(t_next) || (lsl_get_mpointer_ptr(t)->key < search_key)); /* B1 */
    r_node = t;

    /* 2 : check nodes are adjacent */
    if (l_node_next == r_node)
      if ((r_node != list->tail) && lsl_get_mpointer_marked(lsl_get_mpointer_ptr(r_node)->next)) {
        lsl_assume(allow_retries);
        continue; /* G1 */
      }
      else
        return r_node; /* R1 */

    /* 3 : Remove one or more marked nodes */
    if (lsl_cas_ptr1 (&(lsl_get_mpointer_ptr(*l_node)->next), l_node_next, r_node)) /* C1 */
      if ((r_node != list->tail) && lsl_get_mpointer_marked(lsl_get_mpointer_ptr(r_node)->next)) {
        continue; /* G2 */
      }
      else
        return r_node; /* R2 */

  } while (TRUE);  /* B2 */
}

boolean_t contains(list_t *list, value_t search_key, boolean_t allow_retries)
{
  mpointer_t r_node, l_node;

  r_node = search(list, search_key, &l_node, allow_retries);
  if ((r_node == list->tail) || (lsl_get_mpointer_ptr(r_node)->key != search_key))
    return FALSE;
  else
    return TRUE;
}

boolean_t add(list_t *list, value_t key, boolean_t allow_retries)
{
  mpointer_t n_node, r_node, l_node;

  n_node = lsl_make_mpointer(lsl_malloc_noreuse(sizeof(node_t)), FALSE);
  (lsl_get_mpointer_ptr(n_node))->key = key;

  do {
    r_node = search(list, key, &l_node, allow_retries);
    if ((r_node != list->tail) && (lsl_get_mpointer_ptr(r_node)->key == key)) /*T1*/
      return FALSE;
    lsl_get_mpointer_ptr(n_node)->next = r_node;
    if (lsl_cas_ptr2( &(lsl_get_mpointer_ptr(l_node)->next), r_node, n_node)) /*C2*/
      return TRUE;
    lsl_assume(allow_retries);
  } while(TRUE); /*B3*/
}

boolean_t remov(list_t *list, value_t search_key, boolean_t allow_retries)
{
  mpointer_t r_node, r_node_next, l_node;

  do {
    r_node = search(list, search_key, &l_node, allow_retries);
    if ((r_node == list->tail) || (lsl_get_mpointer_ptr(r_node)->key != search_key)) /*T1*/
      return FALSE;
    r_node_next = lsl_get_mpointer_ptr(r_node)->next;
    if (! lsl_get_mpointer_marked(r_node_next))
      if (lsl_cas_ptr3( &(lsl_get_mpointer_ptr(r_node)->next), r_node_next, lsl_set_mpointer_marked(r_node_next, TRUE))) /*C3*/
        break;
    lsl_assume(allow_retries);
  } while (TRUE);  /*B4*/

  if (allow_retries) {
    if (! lsl_cas_ptr4(&(lsl_get_mpointer_ptr(l_node)->next), r_node, r_node_next)) /*C4*/
      r_node = search (list, lsl_get_mpointer_ptr(r_node)->key, &l_node, allow_retries);
  }
  return TRUE;
}
