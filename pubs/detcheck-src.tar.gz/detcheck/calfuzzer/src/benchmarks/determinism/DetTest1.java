/**
 * Copyright (c) 2009,
 * Jacob Burnim <jburnim@cs.berkeley.edu>
 * All rights reserved.
 * <p/>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 * <p/>
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * <p/>
 * 2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * <p/>
 * 3. The names of the contributors may not be used to endorse or promote
 * products derived from this software without specific prior written
 * permission.
 * <p/>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package benchmarks.determinism;

import java.util.Random;

import static edu.berkeley.cs.detcheck.Determinism.openDeterministicBlock;
import static edu.berkeley.cs.detcheck.Determinism.closeDeterministicBlock;
import static edu.berkeley.cs.detcheck.Determinism.requireDeterministic;
import static edu.berkeley.cs.detcheck.Determinism.assertDeterministic;
import static edu.berkeley.cs.detcheck.Predicate.ApproxEquals;

public class DetTest1 {

    public static Random rnd = new Random();

    static class R1 implements Runnable {
        public void run() {
            try {
                Thread.sleep(rnd.nextInt(2000));

                openDeterministicBlock();
                requireDeterministic(1);
                Thread.sleep(rnd.nextInt(2000));
                assertDeterministic(2);
                closeDeterministicBlock();

                Thread.sleep(rnd.nextInt(2000));

                openDeterministicBlock();
                requireDeterministic(1);
                Thread.sleep(rnd.nextInt(2000));
                assertDeterministic(3);
                closeDeterministicBlock();

            } catch (Exception e) {
                System.err.println(e);
                System.exit(1);
            }
        }
    }


    static class R2 implements Runnable {
        public void run() {
            try {
                Thread.sleep(rnd.nextInt(2000));

                openDeterministicBlock();
                requireDeterministic(1);

                Thread t1 = new Thread(new R1());
                Thread t2 = new Thread(new R1());
                t1.start();
                t2.start();

                t1.join();
                t2.join();

                assertDeterministic(4);
                closeDeterministicBlock();

            } catch (Exception e) {
                System.err.println(e);
                System.exit(1);
            }
        }
    }

    public static void main(String args[]) throws Exception {
        openDeterministicBlock();
        requireDeterministic(1);

        for (int i = 1; i <= 4; i++) {
            openDeterministicBlock();
            requireDeterministic(10*i);

            Thread t1 = new Thread(new R2());
            Thread t2 = new Thread(new R2());
            t1.start();
            t2.start();

            t1.join();
            t2.join();

            assertDeterministic(10*i);
            closeDeterministicBlock();
        }

        assertDeterministic(5);
        closeDeterministicBlock();
    }
}
