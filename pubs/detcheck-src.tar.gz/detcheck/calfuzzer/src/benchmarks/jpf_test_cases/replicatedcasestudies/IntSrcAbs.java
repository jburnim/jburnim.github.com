package benchmarks.jpf_test_cases.replicatedcasestudies;

//package signs;

public class IntSrcAbs {
/**
 * 
 * @return java.lang.String
 * @param value int
 */
public static String getToken(int value) {
	return "" + value;
}
}
